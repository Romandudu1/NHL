import * as React from 'react';
import PropTypes from 'prop-types';


import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import {Redirect} from 'react-router-dom';

function TabPanel(props:any) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index:any) {
  
  return {
    id: `full-width-tab-${index}`,
    'aria-controls': `full-width-tabpanel-${index}`,
  };
}

const FullWidthTabs:React.FC<any>=(props)=>{

  const [value, setValue] = React.useState(1);

  const handleChange = (event:any, newValue:number) => {
    console.log('values is ' + newValue)
    setValue(newValue);
  };
  //debugger;
 

  return (
    <Box sx={{ bgcolor: 'background.paper', width: '100%'}}>
      <AppBar position="static">
      
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="secondary"
          textColor="inherit"
          variant="fullWidth"
          aria-label="full width tabs example"
        >
          <Tab  label='Sign UP' {...a11yProps(0)} />
         <Tab label="Schedule" {...a11yProps(1)} />
          <Tab label="Data" {...a11yProps(2)} />
        
        </Tabs>
        
  
      </AppBar>
       <TabPanel value={value} index={0}>
       
        {<Redirect to='/Sign UP' />}
      </TabPanel> 
      
      <TabPanel value={value} index={1}>
      {<Redirect to='/Schedule' />}
      
      </TabPanel>
      <TabPanel value={value} index={2}>
      {<Redirect to='/DataMain' />}
      </TabPanel>
      <TabPanel index={3} value={value}>{<Redirect to='/Cutting Engineering' />}</TabPanel>
      <TabPanel index={4} value={value}>{<Redirect to='/Quality Engineering' />}</TabPanel>
    </Box>
  );
}

export default React.memo(FullWidthTabs)