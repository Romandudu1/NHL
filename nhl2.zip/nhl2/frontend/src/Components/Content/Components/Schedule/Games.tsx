import React, {useState} from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {GamesType} from '../../../../redux/reducers/nhlReducer'
import { useSelector } from 'react-redux';
import { AppStateType } from '../../../../redux/redux-store';
import TeamInSchedule from './Teams/DataUpload'
type PropsType={
    games:Array<GamesType>
}
const Games:React.FC<PropsType>=(props)=>{
  const [expanded, setExpanded] = useState<boolean|string>(false);
  const GamesSelector=useSelector((state:AppStateType)=>(state.nhl.games))
  console.log('games is ' + GamesSelector)
  const handleChange = (panel:any) => (event:any, isExpanded:boolean) => {
    setExpanded(isExpanded ? panel : false);
  };

  const GamesList = props.games.map(item=>{
    const index = props.games.map(object => object.homeTeam).indexOf(item.homeTeam);
      return(
        <Accordion key={index}  style={{border:'silver 1px solid'}} expanded={expanded === 'panel' + index} onChange={handleChange('panel' + index)}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography sx={{ fontSize:'1.3vw',  width: '33%', flexShrink: 0 }}>
           {item.homeTeam}
          </Typography>
          <Typography sx={{ color: 'text.secondary', fontSize:'1.3vw', width: '33%', }}>{item.awayTeam}</Typography>
          <Typography sx={{ fontSize:'1.3vw',  width: '33%', flexShrink: 0 }}>
           {item.timeOfStart.replace(/['T''Z']/g, '  ')}
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
         <TeamInSchedule team1={item.homeTeamId} team2={item.awayTeamId} />
        </AccordionDetails>
      </Accordion>
      )
  })

  return (
    <div style={{width:'70vw', marginLeft:'15vw'}}>

     {GamesList}
      
    </div>
  );
}


export default React.memo(Games)