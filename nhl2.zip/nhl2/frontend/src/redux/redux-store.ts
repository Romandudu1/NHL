import { combineReducers, applyMiddleware, createStore } from "redux";

import thunk from "redux-thunk";
import { authReducer } from "./reducers/authReducer";
import { productionReducer } from "./reducers/productionReducer";
import { equipmentReducer } from "./reducers/equipmentReducer";
import { nhlReducer } from "./reducers/nhlReducer";
let reducers = combineReducers({

    authorization: authReducer,
    production: productionReducer,
    equipment: equipmentReducer,
    nhl:nhlReducer
});

type rootReducerType = typeof reducers
export type AppStateType = ReturnType<rootReducerType>

let store = createStore(reducers, applyMiddleware(thunk));
type PropertiesTypes<T> =T extends {[key:string]:infer U}?U:never
export type InferActionTypes<T extends {[key:string]:(...args:any[])=>any}> = ReturnType<PropertiesTypes<T>>
//window.store= store;

export default store;
