import "antd/dist/antd.less";
import "antd/dist/antd.css";
import "./index.css";
import { Row } from "antd";
import {getNeededKoef} from './selectors/getNeededKoef'
import { getPlayersLevel } from "./selectors/getPlayersLevel";
import { getTeamsList, getTeamRoster } from "../../../../../api/apiNHL";
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import TeamSelected from "./TeamSelected";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import { Progress, Tooltip } from 'antd';

import LinearProgress from '@mui/material/LinearProgress';
import Typography from "@mui/material/Typography";
const MainCombinations: React.FC<any> = (props: any) => {
  const [selectedTeams, setSelectedTeams]=useState<{team1:number, team2:number}>({
    team1:0,
    team2:0
  })

  const [teamsOptions, setTeamsOptions] = useState<Array<object>>([]);
  const [roster, setRoster] = useState<Array<object>>([{}]);
  const [roster2, setRoster2] = useState<Array<object>>([{}]);
  const [defender, setDefender] = useState<number>(0);
  const [goalkeeper, setGoalkeeper] = useState<number>(0);
  const [forward, setForward] = useState<number>(0);
  const [defender2, setDefender2] = useState<number>(0);
  const [goalkeeper2, setGoalkeeper2] = useState<number>(0);
  const [isLoading, setIsLoading]=useState<boolean>(false)
  const [forward2, setForward2] = useState<number>(0);
  useEffect(() => {
    getTeamsList().then((res) => {
     
      let arrayOfOptions = res.data.teams.map((item: any) => {
        return (
          <MenuItem value={item.id} key={item.id}>
            {item.name}
          </MenuItem>
        );
      });
      setTeamsOptions(arrayOfOptions);
    });
  }, [roster, roster2, isLoading]);
  let team1Possibility:number|any = (((defender+goalkeeper+forward)/((defender+goalkeeper+forward) + (defender2+goalkeeper2+forward2)))*100).toFixed(2)
  let koef:number = getNeededKoef(team1Possibility)
  const onChangeTeam = (prop: string) => async (event: any) => {
 setIsLoading(true)
    getTeamRoster(event.target.value).then(async (res) => {
      let response: any = await getPlayersLevel(res.data.roster);
     
      if (prop === "roster") {
        setSelectedTeams({...selectedTeams, team1:event.target.value})
        setRoster(response.roster);
        setForward(response.forwards);
        setDefender(response.defencemans);
        setGoalkeeper(response.goalkeepers);
      } else if (prop === "roster2") {
        setSelectedTeams({...selectedTeams, team2:event.target.value})
        setSelectedTeams({...selectedTeams, team2:event.target.value})
        setRoster2(response.roster);
        setForward2(response.forwards);
        setDefender2(response.defencemans);
        setGoalkeeper2(response.goalkeepers);
      }
      setIsLoading(false)
    });
   
  };
if(!isLoading){
  return (
    <Box>
      <Tooltip title={'acceptable koef fora(0) is ' + koef.toFixed(2)}>
      <Progress
      style={{width:'50vw', marginLeft:'20vw', marginBottom:'2vw'}}
        percent={team1Possibility}
        success={{
          percent: team1Possibility,
        }}
       
      />
    </Tooltip>
      <Grid container spacing={2}>
        <Card
          style={{
            width: "40vw",
            marginLeft: "5vw",
            border: "1px solid silver",
          }}
        >
          <FormControl fullWidth>
            <InputLabel
              style={{
                marginLeft: "10vw",
                marginTop: "1vw",
                marginBottom: "5vw",
              }}
              variant="outlined"
              htmlFor="uncontrolled-native"
            >
              Team1
            </InputLabel>
            <Select
              placeholder="select team"
              label="Team1"
              style={{ width: "17vw", marginTop: "1vw", marginLeft: "10vw" }}
              defaultValue={selectedTeams.team1}
              onChange={onChangeTeam("roster")}
              inputProps={{
                name: "age",
                id: "uncontrolled-native",
              }}
            >
              {teamsOptions}
            </Select>
          </FormControl>
          <Row style={{ width: "50vw" }}>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Goalkeepers
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {goalkeeper.toFixed(2)}
              </Typography>
            </Card>

            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Deffenders
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {defender.toFixed(2)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Forwards
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {forward.toFixed(2)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Team2
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {(goalkeeper + defender + forward).toFixed(2)}
              </Typography>
            </Card>
          </Row>

          <TeamSelected roster={roster} />
        </Card>
        <Card
          style={{
            width: "40vw",
            marginLeft: "5vw",
            border: "1px solid silver",
          }}
        >
          <FormControl fullWidth>
            <InputLabel
              style={{
                marginLeft: "10vw",
                marginTop: "1vw",
                marginBottom: "5vw",
              }}
              variant="outlined"
              htmlFor="uncontrolled-native"
            >
              Team2
            </InputLabel>
            <Select
              placeholder="select team"
              label="Team"
              style={{ width: "17vw", marginTop: "1vw", marginLeft: "10vw" }}
              defaultValue={selectedTeams.team2}
              onChange={onChangeTeam("roster2")}
              inputProps={{
                name: "age",
                id: "uncontrolled-native",
              }}
            >
              {teamsOptions}
            </Select>
          </FormControl>
          <Row style={{ width: "50vw" }}>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Goalkeepers
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {goalkeeper2.toFixed(2)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Deffenders
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {defender2.toFixed(2)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Forwards
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {forward2.toFixed(2)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "8vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "1vw" }}
                color="text.secondary"
                gutterBottom
              >
                Teams
              </Typography>
              <Typography sx={{ fontSize: "2vw" }} variant="h5" component="div">
                {(goalkeeper2 + defender2 + forward2).toFixed(2)}
              </Typography>
            </Card>
          </Row>

          <TeamSelected roster={roster2} />
        </Card>
      </Grid>
    </Box>
  );
}
else{
  return   (<Box sx={{ width: '70%', marginLeft:'15%' }}>
  <LinearProgress />
</Box>)
}
};
export default React.memo(MainCombinations);
