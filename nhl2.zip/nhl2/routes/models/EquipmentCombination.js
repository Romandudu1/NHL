const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let EquipmentEngineeringSchema = new Schema({
    ['Загальний переріз']: {
        type: Number
       
    },

    typeOfConnection:
    {
        type: String,
        required:true
    },
    deadline:{
        type:Date,
        required:true
    },
    project:{
        type:String,
        required:true
    },
    
    location:{
        type:String,
        required:true
    }, 

    assigned:{
        type:String,
        required:true
    }, 

    ['Опис комбінацій']:{
        type:String
       
    },
   
    ['Druck /  Тиск']:{
        type:String
    },
    ['Druck_10%']:{
        type:String
    },
    ['Breite / Ширина']:{
        type:String},

    ['Breite_10%']:{
        type:String
    },
    ['Amplitude/Амплітуда']:{
        type:String
    },
    ['Amplitude_10%']:{
        type:String
    },
    ['Amplitude_-10%']:{
        type:String
    },
    ['Energie/Енергія']:{
        type:String
    },
    ['Energie_10%']:{
        type:String
    },
    ['Data/Дата затвердження']:{
        type:String
    },

    ['№ програми']:{
        type:String
    },
    
    equipment:{
        type:String
      
    },
    user:{
        type:String
      
    },
    dateOfAdding:{
        type:Date
    },
    commentsShlifbild:{
        type: String,
    },
    commentsZryv:{
        type: String,
    },
    technik:{
        type:String 
     },
    statusShlifbild:{
        type:String
        
    },
    statusZryv:{
        type:String,
      
    },

    imageShlifbild:{
        type:String
      
       
    },

    imageZryv:{
        type:String
      
     },
}, {
    collection: 'EquipmentEngineering'
})

module.exports = mongoose.model('EquipmentEngineering', EquipmentEngineeringSchema)