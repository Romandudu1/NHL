export const getNeededKoef=(possibility:number)=>{
let totalOfLosings:number = (100-possibility)*100
let neededKoef:number = ((totalOfLosings/possibility) + ((totalOfLosings/possibility)*0.1))/100
console.log('needed koef is ' + neededKoef)
let Koef:number = 1 + parseFloat(neededKoef.toFixed(2))
return Koef
}