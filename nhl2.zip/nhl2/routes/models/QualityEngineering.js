const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let QualityEngineeringSchema = new Schema({
    typeOfConnection:
    {
        type: String,
        required:true
    },
    deadline:{
        type:Date,
        required:true
    },
    project:{
        type:String,
        required:true
    },
    
    location:{
        type:String,
        required:true
    }, 

    assigned:{
        type:String,
        required:true
    }, 
    
    
    combination: {
        type: String,
        required: true

    },
    crossSection: {
        type: Number,
        required: true

    },

    program: {
        type: Number,
        required:true
    },
    equipment: {
        type: String,
        required:true
    },
    user: {
        type: String,
        required:true
    },
    technik:{
       type:String 
    },
    
    dateOfAdding: {
        type: Date,
        required:true
    },
    pressure: {
        type: Number,
        required:true,

    },
    width: {
        type: Number,
        required:true
    },
    amplitude: {
        type: Number,
        required:true
    },
    energie: {
        type: Number,
        required:true
    },
    comments: {
        type: String
    },
    commentsShlifbild:{
        type: String,
    },
    commentsZryv:{
        type: String,
    },

    statusShlifbild:{
        type:String,
        required:true
    },
    statusZryv:{
        type:String,
        required:true
    },
    imageShlifbild:{
       type:String
     
    },
    imageZryv:{
        type:String
      
     },



    

}, {
    collection: 'QualityEngineering'
})

module.exports = mongoose.model('QualityEngineering', QualityEngineeringSchema)