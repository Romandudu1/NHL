const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let CombinationForValidationSchema = new Schema({
    NameOfSender: {
        type: String,
        required:true
    },
    Deadline:{
        type:String,
        required:true
    },
    Project:{
        type:String,
        required:true
    },
    Assigned:{
        type:String,
        required:true
    },
       

    Combination: {
        type: String
        
    },
    Check: {
        type: String
        
    },
    Connection:{type:String},
    Type:{type:String},
    Product:{type:String},
    Quantity:{type:String},
    Contact:{type:String},
    Seal:{type:String},
    Equipment:{type:String},
    Shrinking:{type:String},
    Type:{type:String},
    Equipment2:{type:String},
    Sleeve:{type:String},
    Length:{type:String},   



}, {
    collection: 'CombinationForValidation'
})

module.exports = mongoose.model('CombinationForValidation', CombinationForValidationSchema)