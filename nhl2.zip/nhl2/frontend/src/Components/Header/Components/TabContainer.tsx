
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';
import Tab from "./Tab";
import {compose} from "redux";
import React from 'react'
import {AppStateType} from  '../../../redux/redux-store'
import {initialStateType} from '../../../redux/reducers/authReducer'
let mapStateToProps = (state:AppStateType):initialStateType=> {

    return state.authorization
}


export default React.memo(compose<React.FC>(
    connect<initialStateType,{},{}, AppStateType>(mapStateToProps, {}),
   withRouter
)
(Tab))