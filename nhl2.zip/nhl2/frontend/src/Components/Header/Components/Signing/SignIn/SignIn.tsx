import * as React from 'react';
import {useState} from 'react'
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import AssignmentIcon from '@material-ui/icons/LockOpen';
import FormControl from '@mui/material/FormControl';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import {userTypeSignIn, userType} from "../../../../../redux/reducers/authReducer";

type PropsType={
  isAuth:boolean
  isUniqueEmail:boolean
  message:string
  user:userType,
  signInUser:(user:userTypeSignIn)=>void

}
type valuesType={
  password:string
  email:string,
  showPassword:boolean

}

const  SignIn:React.FC<PropsType>=(props)=>{
  
  const [values, setValues] = useState<valuesType>({
   password: '',
   email: '',
   showPassword: false,
  });
   
   


  const handleChange = (prop:string) => (event:any) => {
    setValues({ ...values, [prop]: event.target.value });
  };
  const signInOnClick =()=>{
     console.log(values.password)
    props.signInUser(values)
}
  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword,
    });
  };

  const handleMouseDownPassword = (event:any) => {
    event.preventDefault();
  };
  return (
    <div style={{color:'#6f6d6d'}}>
        
     <Box
     
      component="form"
      sx={{bgcolor: 'background.paper',
        '& .MuiTextField-root': { m: 1 }, marginLeft:'35%', 
      }}
      noValidate
      autoComplete="off"
    >
      <Avatar sx={{marginLeft:'24%',  bgcolor: '#f50057' }}>
        <AssignmentIcon />
      </Avatar>
      <Typography sx={{marginLeft:'21.5%'}}  variant='h4' color='textPrimary'  gutterBottom component="div" >
  Sign in
</Typography>

     
      <div>
       
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
          <InputLabel htmlFor="outlined-adornment-email">Email Address</InputLabel>
          <OutlinedInput
            id="outlined-adornment-email"
            type='text'
            value={values.email}
            onChange={handleChange('email')}
            required
            label="Email Address"
          />
        </FormControl>
      </div>
      <div>
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
          <InputLabel htmlFor="outlined-adornment-password">Password</InputLabel>
          <OutlinedInput
            id="outlined-adornment-password"
            type={values.showPassword ? 'text' : 'password'}
            value={values.password}
            required
            onChange={handleChange('password')}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {values.showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />
        </FormControl>

      </div>
      <FormGroup>
      <FormControlLabel  sx={{color:'#d7dac4', width: '52%',  marginLeft:'1%'}} control={<Checkbox  />} label='Remember me'/>
  
    </FormGroup>
    <Button sx={{ m: 1, width: '52%' }} onClick={signInOnClick} variant="contained">SIGN IN</Button>
   
    </Box>
 
    </div>
  );
}

export default React.memo(SignIn)