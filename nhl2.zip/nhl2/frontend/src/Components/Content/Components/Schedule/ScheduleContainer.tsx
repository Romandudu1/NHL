import {connect} from 'react-redux';
import React from 'react';
import Schedule from "./Schedule";
import {AppStateType} from '../../../../redux/redux-store'
import {initialStateType} from '../../../../redux/reducers/nhlReducer'
import {getGames} from '../../../../redux/reducers/nhlReducer'

export type mapDispatchToPropsType={
    getGames:(date:string)=>void
}

let mapStateToProps = (state:AppStateType):initialStateType=> {

    return state.nhl
    

}


export default   React.memo(connect<initialStateType, mapDispatchToPropsType, {}, AppStateType  >(mapStateToProps, {getGames})(Schedule));