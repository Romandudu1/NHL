import {connect} from 'react-redux';
import {setUser, checkEmail, initialStateType, userType} from "../../../../../redux/reducers/authReducer";
import SignUp from "./SignUp";
import {compose} from "redux";

import {AppStateType} from  '../../../../../redux/redux-store'
type MapDispatchToPropsType={
    checkEmail:(email:string)=>void
    setUser:(user: userType)=>void
}

let mapStateToProps = (state:AppStateType):initialStateType=> {

    return  state.authorization
    

}



export default compose(connect<initialStateType, MapDispatchToPropsType, {}, AppStateType>(mapStateToProps, {setUser,checkEmail} ))(SignUp);