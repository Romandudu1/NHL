import * as React from 'react';
import MainMenu from './Components/MainMenu'
import MainTab from './Components/TabContainer'
const Header:React.FC<any>=()=> {
 

  return (
    <div>
        <MainMenu />
        <MainTab />
    </div>
  );
}
export default React.memo(Header);