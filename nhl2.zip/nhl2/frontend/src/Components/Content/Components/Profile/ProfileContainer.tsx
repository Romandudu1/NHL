import {connect} from 'react-redux';
import React from 'react'
import Profile from "./Profile";
import {AppStateType} from '../../../../redux/redux-store'
import {initialStateType} from '../../../../redux/reducers/authReducer'


let mapStateToProps = (state:AppStateType):initialStateType=> {

    return state.authorization
    

}


export default   React.memo(connect<initialStateType, {}, {}, AppStateType>(mapStateToProps, {})(Profile));