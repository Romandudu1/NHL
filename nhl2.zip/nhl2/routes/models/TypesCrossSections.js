const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let TypesCrossSectionSchema = new Schema({
    Wire_Type: {
        type: String,
        required:true
    },
    ReducingKanBan:{
        type:String,
        required:true
    },
    ReducingShrinking:{
        type:String,
        required:true
    },
    CrossSection:{
        type:String,
        required:true
    },
    

}, {
    collection: 'TypesCrossSection'
})

module.exports = mongoose.model('TypesCrossSection', TypesCrossSectionSchema)