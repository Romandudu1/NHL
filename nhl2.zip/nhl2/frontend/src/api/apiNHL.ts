import  axios from 'axios';

export const  instance = axios.create({
    baseURL:'https://statsapi.web.nhl.com/api/v1',

})
export const  instanceRapid = axios.create({
    baseURL:'https://odds.p.rapidapi.com/v4/sports/icehockey_sweden_allsvenskan/odds',
    headers: {
        'X-RapidAPI-Key': 'aff739c959mshc1dad8b5d02fec5p14bec8jsn27cbc92d71fe',
        'X-RapidAPI-Host': 'odds.p.rapidapi.com'
      }
})

export const  instanceOdds = axios.create({
    baseURL:'https://api.the-odds-api.com/v4/sports/icehockey_sweden_allsvenskan/odds/?apiKey=b88515a64af0d911c88d584c6b8363ba&regions=eu&markets=h2h,spreads&oddsFormat=decimal',
   
})


type responseRosterType={
    copyright:string
    roster:Array<playerRosterType>
    link:string
}
type playerRosterType={
    person:{
        id:number,
        fullName:string,
        link:string
    }
    jerseyNumber:string
    position:{
        code:string
        name:string
        type:string
        abbreviation:string
    }
}

type responseTeamsType={
    copyright:string,
    teams:Array<teamType>
}
    
type teamType={
    id:number
    name:string
    link:string
    venue:{
        name:string
        link:string,
        city:string
    }
    timeZone:{
        id:string,
        offset:number
        tz:string
    }
    abbreviation:string
    teamName:string
    locationName:string
    firstYearOfPlay:string
    division:{
        id:number
        name:string
        nameShort:string
        link:string
        abbreviation:string
    }
    conference:{
        id:number
        name:string
        link:string

    }
     franchise:{
         franchiseId:number
         teamName:string
         link:string
     }
     shortName:string
     officialSiteUrl:string
     franchiseId:number
     active:boolean
}

type playerStatDetailedType={
    season:string,
    stat:{
    timeOnIce:string,
    assists:number
    goals:number
    pim:number
    shots:number
    games:number
    hits:number
    powerPlayGoals:number
    powerPlayPoints:number
    powerPlayTimeOnIce:string
    evenTimeOnIce:string
    penaltyMinutes:string
    faceOffPct:number
    shotPct:number
    gameWinningGoals:number
    overTimeGoals:number
    shortHandedGoals:number
    shortHandedPoints:number
    shortHandedTimeOnIce:string
    blocked:number
    plusMinus:number
    points:number
    shifts:number
    timeOnIcePerGame:string
    evenTimeOnIcePerGame:string
    shortHandedTimeOnIcePerGame:string
    powerPlayTimeOnIcePerGame:string
    }
}

type responsePlayerStatsType={
copyright:string
stats:Array<playerStatsType>
}

type splitsType={
    season:string
    stat:playerStatDetailedType
}

type playerStatsType={
    type:{
        displayName:string
    gametype:{
        id:string
        description:string
        postseason:boolean
    }
     splits:Array<splitsType>
    }

}

export const getOddsRapid=(date:string)=>{
   
    return instanceRapid.get('/')
}

export const getOdds=(date:string)=>{
   
    return instanceOdds.get('/')
}


export const getGamesList=(date:string)=>{
    const request = '/schedule/?date=' + date
    return instance.get(request)
}

export const getTeamsList=()=>{
   
    return  instance.get<responseTeamsType>('/teams')
}

export const getTeamRoster=(id:number)=>{
    const request:string = '/teams/' + id  + '/roster'
    return  instance.get<responseRosterType>(request)
}

export const getPlayerDataPrev=(id:number)=>{
    const request = '/people/' + id  + '/stats/?stats=statsSingleSeason&season=20212022'
    return  instance.get<responsePlayerStatsType|any>(request)
}

export const getPlayerDataLast=(id:number)=>{
    const request = '/people/' + id  + '/stats/?stats=statsSingleSeason&season=20222023'
    return  instance.get<responsePlayerStatsType|any>(request)
}


