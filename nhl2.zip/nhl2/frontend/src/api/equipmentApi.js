import  axios from 'axios';

//import unsplash from 'unsplash-js'
export const  instance = axios.create({
    baseURL:'http://localhost:4000/equipment/',
    
})



 export const dropInventoryPositions = ()=>{
   
    return  instance.post('/dropInventoryBase')
}


export const exportInventoryPositions =()=>{
   
    return  instance.post('/exportInventoryPositions')
}


export const getExistCodeOrNo =(code)=>{
   
    return  instance.post('/existCodeOrNo', {code})
}

export const addPositionToInventory =(data)=>{

    return  instance.post('/addPositionToInventory', {data})

}

export const getLastUpdated =()=>{

    return  instance.get('/getLastUpdated')

}

export const loadingBaseInventory =(data, filename)=>{
    
    return  instance.post('/loadingBaseInventory', {data, filename})
}
export  const  addEquipmentApi=(equipment)=>{
   
    return instance.post('/addEquipment', {equipment}) }

    export  const  acceptShlifbildApi=(request)=>{
   
        return instance.post('/acceptShlifbild', {request}) }
       
        export  const rejectZryvApi=(request, imageUploaded)=>{
   
            return instance.post('/rejectZryv', {request, imageUploaded}) }
       
            
        export  const rejectShlifbildApi=(request, imageUploaded)=>{
   
            return instance.post('/rejectShlifbild', {request, imageUploaded}) }

    export  const  addRequestToQualityApi=(request)=>{
   
    return instance.post('/addRequestToQuality', {request}) }

    export  const  imageUploadShlifbildApi=(request, imageUploaded)=>{
         
        return instance.post('/imageUploadShlifbild', {request,imageUploaded}) }
       
        export  const commentUploadShlifbildApi=(request, comment)=>{
         
            return instance.post('/commentUploadShlifbild', {request, comment}) }

            export  const acceptZryvApi=(request)=>{
         
                return instance.post('/acceptZryv', {request}) }

            export  const commentUploadZryvApi=(request, comment)=>{
         
                return instance.post('/commentUploadZryv', {request, comment}) }

    export  const  deleteEquipmentApi=(equipment)=>{
   
        return instance.post('/deleteEquipment', {equipment}) }
        

        export const getEquipmentToExcel=()=>{
            return instance.post('/getEquipmentToExcel', {})
        }

        export const getBaseToExcel=()=>{
            return instance.post('/getBaseToExcel', {})
        }

        export  const  getRequestsToEquipment=()=>{
         
            return instance.get('/getRequestsToEquipment')}
           
            export  const  getRequestsToStatus=(user)=>{
         
            return instance.post('/getRequestsToStatus', {user})}

            export  const  getReleasedCombinations=()=>{
         
                return instance.get('/getReleasedCombinations')}

            export  const  getRequestsToQuality=()=>{
         
                return instance.get('/getRequestsToQuality')}