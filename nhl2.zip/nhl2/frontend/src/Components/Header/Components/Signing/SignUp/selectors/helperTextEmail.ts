import validator from 'validator'

export const helperText=(email:string, blurEmail:boolean, unique:boolean)=>{
  
    if(blurEmail&&(!validator.isEmail(email))){
       
        return 'Please set correct email!!!'
    }
      
    
    else if(blurEmail && !unique){
        
        return ('your email is not unique!')
    }
  
    else
    return ''
  }