import React, {useEffect, useState} from "react";
import LinearProgress from '@mui/material/LinearProgress';
import ButtonGroup from '@mui/material/ButtonGroup';
import Button from '@mui/material/Button';
import {GamesType} from '../../../../redux/reducers/nhlReducer'
import Games from './Games'
import Box from "@mui/material/Box"
type PropsType={
  dates: Array<string>
  games: Array<GamesType>
  getGames:(date:string)=>void
}

const PE: React.FC<PropsType> = ({games, dates, getGames}) => {
  const[isLoading, setIsLoading]=useState<boolean>(false)
  const changeDate=(event:any)=>{
    setIsLoading(true)
    console.log('event is ' + event.target.value)
    getGames(event.target.value)
    setIsLoading(false)
  }

  useEffect(() => {
    
   if(games.length===1 && games[0].awayTeam===''){
     
       getGames('2022-10-08')
      
   }
  }, [isLoading, getGames, games])
  /* var token = localStorage.getItem('jwt')
  var decoded = token ? jwt.decode(token) : '';
  var Requestor = decoded.name*/


  if(!isLoading){
    return (<div style={{ backgroundColor: "#fff" }}>
    <Box>

    <ButtonGroup style={{marginLeft:'35vw', marginBottom:'3vw'}} disableElevation variant="contained">
      <Button value={dates[0]} onClick={changeDate}>{dates[0]}</Button>
      <Button value={dates[1]} onClick={changeDate}>{dates[1]}</Button>
      <Button value={dates[2]} onClick={changeDate}>{dates[2]}</Button>
    </ButtonGroup>

    </Box>

   <Games games ={games} />
  </div>
);
  }
  else{
    return   (<Box sx={{ width: '70%', marginLeft:'15%' }}>
    <LinearProgress />
  </Box>)
  }
    
};
export default React.memo(PE);
