import React from 'react';
import s from  './Content.module.css';
import { Switch, Route} from 'react-router-dom';
import SignInContainer from '../Header/Components/Signing/SignIn/SigningContainer'
import SignUpContainer from '../Header/Components/Signing/SignUp/SignUpContainer'
import ScheduleContainer from './Components/Schedule/ScheduleContainer'
import EquipmentEngineering from './Components/Equipment Engineering/EquipmentEngineering'


import ProfileContainer from './Components/Profile/ProfileContainer'
import MyGroupContainer from './Components/MyGroup/MyGroupContainer'
import {initialStateType} from '../../redux/reducers/authReducer'
import Data from '../Content/Components/Equipment Engineering/Components/DataUpload'



type propsType={
    state:initialStateType
}
const Content:React.FC<propsType>=(props) =>{ 

return (

<div style={{color:'background.paper'}} className = {s.Content}>
<Switch>
<Route  path="/signIn" >
{props.state.isAuth?<ProfileContainer />:<SignInContainer />}
</Route>

<Route  path='/Sign UP' >
 {props.state.isAuth?<ProfileContainer />:<SignUpContainer />}
</Route>
<Route  path='/Profile'>
{props.state.isAuth?<ProfileContainer />:<SignUpContainer />}
</Route>
<Route  path='/Schedule'>
 {props.state.isAuth?<ScheduleContainer />:<SignUpContainer />}
</Route>
<Route  path='/DataMain'>
 {props.state.isAuth?<EquipmentEngineering />:<SignUpContainer />}
</Route>


<Route exact={false}  path='/Group'>
 {props.state.isAuth?<MyGroupContainer />:<SignUpContainer />}
</Route>




<Route exact={false}  path='/Data'>
 {props.state.isAuth?<Data />:<SignUpContainer />}
</Route>




</Switch>


</div>

)
}

export default React.memo(Content);