module.exports.getEquipment  = async function(crossSection, process){
    
    let EquipmentSchema=require('../models/Equipment')
   
       try{
     
  let  arrayOfEquipment=await EquipmentSchema.find({Process:process/*,  ['Maximal cross section']:{$gt:crossSection}*/})
 
    return arrayOfEquipment[0].Equipment

    }
    catch(e){
      console.log('was misstake import combination xlsx  ' + e.stack)
    }
   
   }