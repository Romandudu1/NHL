import {connect} from 'react-redux';
import React from 'react';
import Content from "./Content";
import {AppStateType} from '../../redux/redux-store'
import {initialStateType} from '../../redux/reducers/authReducer'

type mapStateToPropsType={
    state:initialStateType
}
let mapStateToProps = (state:AppStateType):mapStateToPropsType=> {

    return {
        state:state.authorization
    }

}


export default   React.memo(connect(mapStateToProps, {})(Content));