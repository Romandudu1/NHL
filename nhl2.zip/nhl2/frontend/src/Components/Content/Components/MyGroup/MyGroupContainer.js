import {connect} from 'react-redux';

import MyGroup from "./MyGroup";


let mapStateToProps = (state)=> {

    return {
        state:state
    }

}


export default   connect(mapStateToProps, {})(MyGroup);