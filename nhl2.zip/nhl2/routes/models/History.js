const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let HistorySchema = new Schema({
    process: {
        type: String,
        required:true
    },
    combination:{
        type:String,
        required:true
    },
    history:{
        type:Array
       }
    

}, {
    collection: 'History'
})

module.exports = mongoose.model('History', HistorySchema)