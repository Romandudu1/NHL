import * as React from 'react';

import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';

import CardContent from '@mui/material/CardContent';


import Avatar from '@mui/material/Avatar';

import { red } from '@mui/material/colors';

import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import {NavLink} from 'react-router-dom'
import InboxIcon from '@material-ui/icons/MoveToInbox';
import DraftsIcon from '@material-ui/icons/Drafts';
import AssignmentIcon from '@material-ui/icons/Assignment';
import {initialStateType} from '../../../../redux/reducers/authReducer'


const  Profile:React.FC<initialStateType>=(props)=>{
 
  

 

  
  return (
     
    <Card sx={{ maxWidth: '40%', marginLeft:'30%', backgroundColor:'#6f6d6d' }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            {(props.user.lastName).charAt(0)+(props.user.firstName).charAt(0)}
          </Avatar>
        }
       
        title={<div style={{color:'#303030'}}>{props.user.lastName + ' ' + props.user.firstName}</div> }
        subheader={props.user.email+ ' - Senior Engineer'}
      />
     
      <CardContent>
      <List
      sx={{ width: '100%' }}
      component="nav"
      aria-labelledby="nested-list-subheader"
      
    >
      <ListItemButton>
        <ListItemIcon>
          <AssignmentIcon />
        </ListItemIcon>
        <ListItemText primary="Tasks" />
      </ListItemButton>
      <ListItemButton>
        <ListItemIcon>
          <DraftsIcon />
        </ListItemIcon>
        <ListItemText primary="Requests" />
      </ListItemButton>
      <NavLink to='/Status'>
      <ListItemButton>
        <ListItemIcon>
          <InboxIcon />
        </ListItemIcon>
        <ListItemText primary="Status check" />
      </ListItemButton>
       </NavLink>
    </List>
 
      </CardContent>
     
      
    </Card>
  );
}
export default Profile;