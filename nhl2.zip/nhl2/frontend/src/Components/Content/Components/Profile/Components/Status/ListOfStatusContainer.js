import { connect } from 'react-redux';
import {getStatusRequest} from '../../../../../../redux/reducers/equipmentReducer'
import ListOfStatus from "./ListOfStatus";


let mapStateToProps = (state) => {
    return {
        state: state.equipment
    }

}


export default connect(mapStateToProps, {getStatusRequest})(ListOfStatus);