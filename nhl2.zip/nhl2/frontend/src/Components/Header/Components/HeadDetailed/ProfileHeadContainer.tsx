
import React from 'react'
import {connect} from 'react-redux';
import {logOut} from '../../../../redux/reducers/authReducer'
import ProfileHead from "./ProfileHead";
import {AppStateType} from  '../../../../redux/redux-store'
import {initialStateType} from '../../../../redux/reducers/authReducer'



type mapDispatchToPropsType={
    logOut:()=>void
}

let mapStateToProps = (state:AppStateType):initialStateType=> {

    return state.authorization

}


export default   React.memo(connect<initialStateType, mapDispatchToPropsType, {}, AppStateType>(mapStateToProps, {logOut})(ProfileHead));