import { setUserApi, signInUserApi, checkEmailApi } from "../../api/authUserApi";
import jwt_decode from "jwt-decode";
import { Dispatch } from "redux";

import {InferActionTypes} from "../redux-store"
//import {ThunkAction} from "redux-thunk"
//import {stopSubmit, reset} from "redux-form";
var token: string | null = localStorage.getItem('jwt')
var decoded: any = token ? jwt_decode(token) : '';
console.log(decoded.name)

export const actions={
    authCreator: (user: userType, message: string) =>({type: 'SIGNUP', user,message: message} as const),
    signInCreator:(user: userTypeSignIn, message: string)=>({type: 'SIGNIN',user,message: message} as const),
    uniqueEmailCreator:(isUniqueEmail: boolean)=>({type: "UNIQUEEMAIL",isUniqueEmail}as const),
    logOutCreator:()=>({type: "LOGOUT"}as const)

}

type ActionType = InferActionTypes<typeof actions>

export type initialStateType = {
    message: string,
    user: userType,
    isAuth: boolean,
    isUniqueEmail: boolean
}


export type userType = {
    firstName: string,
    password: string,
    lastName: string,
    email: string,
    showPassword: boolean
}

let initialstate: initialStateType = {
    message: '',
    user: {
        firstName: decoded ? decoded.name.split(' ')[0] : '',
        password: '',
        lastName: decoded ? decoded.name.split(' ')[1] : '',
        email: decoded ? decoded.email : '',
        showPassword: false
    },
    isAuth: decoded.email ? true : false,
    isUniqueEmail: false
};


export const authReducer = (state = initialstate, action: ActionType) => {
    switch (action.type) {
        case "SIGNUP":
            console.log('message is ' + action.message)
            return {
                ...state, user: action.user, message: action.message, isAuth: true
            }

        case "SIGNIN":
            console.log('message is ' + action.message)
            return {
                ...state, user: action.user, message: action.message, isAuth: true
            }
        case "UNIQUEEMAIL":

            return {
                ...state, isUniqueEmail: action.isUniqueEmail
            }

        case "LOGOUT":

            return {
                ...state, message: '',
                user: {
                    firstName: '',
                    password: '',
                    lastName: '',
                    email: '',
                    showPassword: false
                },
                isAuth: false,
                isUniqueEmail: false
            }

        default:
            return state;
    }
}
//type ThunkType=ThunkAction<Promise<void>, AppStateType, unknown, ActionType>
//Sign UP



//Sign IN

export type userTypeSignIn = {
    email: string,
    password: string
}


//Check Unique Email



//LOG OUT



//Sign UP
export const setUser = (user: userType) => (dispatch: Dispatch<ActionType>) => {
    setUserApi(user).then(res => {
        console.log(Object.getOwnPropertyNames(res))
        localStorage.setItem('jwt', res.token)
        dispatch(actions.authCreator(user, res.message))
    })
        .catch(error => {
            alert(error.response.data.message)

        })
}
//Sign In
export const signInUser = (user: userTypeSignIn) => (dispatch: Dispatch<ActionType>) => {
    console.log('inside sign')
    signInUserApi(user).then(res => {
        console.log(Object.getOwnPropertyNames(res.data))
        localStorage.setItem('jwt', res.data.token)
        dispatch(actions.signInCreator(res.data.user, res.data.message))
    })
        .catch(error => {
            console.log(error.response.data.message)
            alert(error.response.data.message)

        })
}

//Log Out
export const logOut = () => (dispatch: any) => {

    localStorage.removeItem('jwt')
    dispatch(actions.logOutCreator())

}

//Check Email
export const checkEmail = (email: string) => (dispatch: Dispatch<ActionType>) => {
    checkEmailApi(email).then(res => {
        dispatch(actions.uniqueEmailCreator(res.data.uniqueEmail))
    })
        .catch(error => {
            alert(error.response.data.message)

        })
}

