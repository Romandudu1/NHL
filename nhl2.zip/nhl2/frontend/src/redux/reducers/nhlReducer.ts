//import {AppStateType} from "../redux-store"
//import {ThunkAction} from "redux-thunk"
import { getGamesList } from '../../api/apiNHL'
//import jwt_decode from "jwt-decode";
import { Dispatch } from "redux";
//import {stopSubmit, reset} from "redux-form";
//var token = localStorage.getItem('jwt')
//var decoded = token ? jwt_decode(token) : '';

export type GamesType = {
    homeTeam: string,
    homeTeamId: number,
    awayTeam: string,
    awayTeamId: number,
    timeOfStart: string
}

export type initialStateType = {
    dates: Array<string>,
    games: Array<GamesType>
}
type actionType = getScheduleGamesCreatorType
var date = new Date()

// Add a day


let initialstate: initialStateType = {
    dates: [new Date().toISOString().slice(0, 10), new Date(date.setDate(date.getDate() + 1)).toISOString().slice(0, 10),
        new Date(date.setDate(date.getDate() + 1)).toISOString().slice(0, 10)],
    games: [{
        homeTeam: '',
        homeTeamId:0,
        awayTeam: '',
        awayTeamId:0,
        timeOfStart: ''

    }]

};
//type ThunkType=ThunkAction<Promise<void>, AppStateType, unknown, actionType>

export const nhlReducer = (state = initialstate, action: actionType) => {

    switch (action.type) {

        case "GETSCHEDULEGAMES":



            return { ...state, games:action.games }



        default:

            return state






    }

}



//get Schedule

const GETSCHEDULEGAMES = "GETSCHEDULEGAMES"
type getScheduleGamesCreatorType = {
    type: typeof GETSCHEDULEGAMES,
    games: Array<GamesType>

}

export const getScheduleGamesCreator = (games: Array<GamesType>): getScheduleGamesCreatorType => {
    return {
        type: "GETSCHEDULEGAMES",
        games
    }
}


export const getGames = (date: string) => {
   return async (dispatch:Dispatch<actionType>) => {

 let res=await getGamesList(date)
   
       var gamesArray:Array<GamesType>=[]
      
       if (res.data.totalGames!==0){
        for(let i=0;i<res.data.dates[0].games.length;i++){
            var item={
             homeTeam: res.data.dates[0].games[i].teams.home.team.name,
             homeTeamId:res.data.dates[0].games[i].teams.home.team.id,
             awayTeam: res.data.dates[0].games[i].teams.away.team.name,
             awayTeamId: res.data.dates[0].games[i].teams.away.team.id,
             timeOfStart: res.data.dates[0].games[i].gameDate
            }
            gamesArray.push(item)
        }
       }
     
        dispatch(getScheduleGamesCreator(gamesArray))
  

}

}





