module.exports.import = async function (stream) {

    let InventorySchema = require('../models/InventoryBase')
    try {
        var arrayxlsx = stream.split('\n')




        var indicator;
        var definingIndicator = arrayxlsx[1].split(',')[0]
        if (definingIndicator.length > 2) {
            indicator = ';'
        }
        else {
            indicator = ','
        }







        for (let i = 1; i < arrayxlsx.length; i++) {
                  
            if (arrayxlsx[i]) {
                kanbanForScan = arrayxlsx[i].split(indicator)[3] ? arrayxlsx[i].split(indicator)[3] : arrayxlsx[i].split(indicator)[3]
                agForScan = arrayxlsx[i].split(indicator)[4] ? arrayxlsx[i].split(indicator)[4].replace(/[\r\n]/g, "") : arrayxlsx[i].split(indicator)[4]
                var insertObject = {
                    position: parseInt(arrayxlsx[i].split(indicator)[0]),
                    place: arrayxlsx[i].split(indicator)[1],
                    name: arrayxlsx[i].split(indicator)[2] ? arrayxlsx[i].split(indicator)[2] : arrayxlsx[i].split(indicator)[2],
                    kanban: arrayxlsx[i].split(indicator)[3] ? arrayxlsx[i].split(indicator)[3] : arrayxlsx[i].split(indicator)[3],
                    ag: arrayxlsx[i].split(indicator)[4] ? arrayxlsx[i].split(indicator)[4].replace(/[\r\n]/g, "") : arrayxlsx[i].split(indicator)[4],
                    scan:'*' + arrayxlsx[i].split(indicator)[0] + '_' + kanbanForScan + '_' + agForScan + '*'
                }

                await InventorySchema.create(insertObject);
            }



        }
        return 'ok'
    }
    catch (e) {
        console.log('was misstake in import strands and terminals ' + e.stack)
        return 'nok'

    }

}