import * as React from 'react';

import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import ArchiveIcon from '@material-ui/icons/Archive';
import CardContent from '@mui/material/CardContent';
import GroupIcon from '@material-ui/icons/Group';
import Avatar from '@mui/material/Avatar';
import {NavLink} from 'react-router-dom'
import Grid from '@mui/material/Grid';
import Fab from '@mui/material/Fab';
import AccountTreeIcon from '@material-ui/icons/AccountTree';

import SettingsIcon from '@material-ui/icons/Settings';

import { red } from '@mui/material/colors';

 const EquipmentEngineering:React.FC<any>=()=>{
  return (
    <div style={{backgroundColor:'#fff'}}>
    <Grid container spacing={1}>
       
          
     <Card sx={{  marginLeft:'20%', bgcolor:'#D3D3D3', width:'25%'}}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            DT
          </Avatar>
        }
       
        title={<h4>Data</h4>}
        
      />
    
    <NavLink to='/Data'>
      <Fab  sx={{ marginLeft:'40%' }} size="large"   title='equipment check' color="primary" aria-label="add">
        <SettingsIcon />
      </Fab>
     </NavLink>
      
      
      <CardContent >
        <Typography variant="body2" color="text.secondary">
        Сторінка для імпорту та експорту даних.
        </Typography>
      </CardContent>
     
    
    </Card>
    
   
    
    <Card sx={{bgcolor:'#D3D3D3',  marginLeft:'10%',  width:"25%" }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            ST
          </Avatar>
        }
       
        title={<h4>Статистика</h4>}
        
      />
    
    <NavLink to='/Equipment Requests'>
      <Fab  sx={{ marginLeft:'40%' }} size="large"   title='watch combinations in process' color="primary" aria-label="add">
        <AccountTreeIcon />
      </Fab>
</NavLink>
      
      
      
      <CardContent>
        <Typography variant="body2" color="text.secondary">
         Перегляд статистики проходження інвентури.
        </Typography>
      </CardContent>
     
    
    </Card>
    
   </Grid>
   <Grid container spacing={1}>
       
          
   <Card sx={{  marginLeft:'20%',   marginTop:'5%', marginBottom:'5%',  bgcolor:'#D3D3D3',  width:'25%'}}>
    <CardHeader
      avatar={
        <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
          AR
        </Avatar>
      }
     
      title={<h4>Архів</h4>}
      
    />
  
    
    <Fab  sx={{ marginLeft:'40%' }} size="large"   title='watch combinations in archive' color="primary" aria-label="add">
      <ArchiveIcon />
    </Fab>

    
    
    
    <CardContent >
      <Typography variant="body2" color="text.secondary">
     Архів попередніх  інвентур
      </Typography>
    </CardContent>
   
  
  </Card>
  
 
  
  <Card sx={{ bgcolor:'#D3D3D3', marginBottom:'5%', marginTop:'5%',  marginLeft:'10%',  width:"25%" }}>
    <CardHeader
      avatar={
        <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
          MG
        </Avatar>
      }
     
      title={<h4>Моя група</h4>}
      
    />
  
  <NavLink to='/Group'>
    <Fab  sx={{marginLeft:'40%' }} size="large"   title='go to my group' color="primary" aria-label="add">
      <GroupIcon />
    </Fab>
</NavLink>
    
    
    
    <CardContent >
      <Typography variant="body2" color="text.secondary">
      Сторінка для додавання чи видалення користувачів
      </Typography>
    </CardContent>
   
  
  </Card>
  
 </Grid>
 </div>
  );
}

export default React.memo(EquipmentEngineering)