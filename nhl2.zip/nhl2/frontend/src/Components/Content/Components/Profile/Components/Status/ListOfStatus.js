
import MainStatus from './MainStatus'


import  jwt  from 'jsonwebtoken'



import Typography from '@mui/material/Typography';




const ListOfStatus = (props) => {
 
    var token = localStorage.getItem('jwt')
    var decoded = token?jwt.decode(token):'';
    


   


    var requestsStatus = []

    if ((props.state[0] && props.state[0].combination === '') || !(Array.isArray(props.state))) {

        props.getStatusRequest(decoded.name)

    }
    else {

        console.log('returned state from server!!!! ')
        requestsStatus = props.state
        console.log(Object.getOwnPropertyNames(requestsStatus))

    }

    const ListOfRequests = requestsStatus.map(item => {
     

        return <MainStatus color='primary' key={item.combination} data={item} />
    })
    return <span>
        <Typography style={{ marginLeft: '17vw', color: '#d7dac4' }} variant="h4" gutterBottom component="div">
            Quantity of requests:{requestsStatus.length}
        </Typography>

        {ListOfRequests}
    </span>
}

export default ListOfStatus