const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let AddInstructionSchema = new Schema({
    wireType: {
        type: String,
        required:true
    },
    crossSection:{
        type:String,
        required:true
    },
    
    wirePartnumber:{
        type:String,
        required:true
    },
    requestor:{
        type:String,
        required:true
    },
    

}, {
    collection: 'AddInstruction'
})

module.exports = mongoose.model('AddInstruction', AddInstructionSchema)