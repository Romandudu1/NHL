module.exports.importCombinations  = async function(stream,  dataObject){
    
    let CombinationForValidationSchema=require('../models/CombinationForValidation')
   
       try{
     var arrayxlsx = stream.split('\n')
 
     const os = require('os');
     var user = os.userInfo(); 
   
     console.log('userName is ' + user.username);
     console.log('user is ' + Object.getOwnPropertyNames(user))
      
   
   for (let i = 1; i < arrayxlsx.length; i++) {
     var indicator;
     var definingIndicator = arrayxlsx[i].split(',')[0]
     if(definingIndicator.length>14){
       indicator = ';'
     }
     else{
       indicator=','
     }
 
                                                 
                                                 
   var insertObject = {
     filename:filename,
    combination: arrayxlsx[i].split(indicator)[0]
   
   }
 
  if(insertObject.wire!==undefined&&insertObject.variante!==undefined){
    await  CombinationForValidationSchema.create(insertObject);
  }
  
    
 
    
   
   }
   
  
   }
    catch(e){
      console.log('was misstake import combination xlsx  ' + e.stack)
    }
   
   }