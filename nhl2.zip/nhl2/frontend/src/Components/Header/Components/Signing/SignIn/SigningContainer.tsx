

import {connect} from 'react-redux';
import {initialStateType, signInUser, userTypeSignIn} from "../../../../../redux/reducers/authReducer";
import SignIn from "./SignIn";
import {AppStateType} from  '../../../../../redux/redux-store'

type MapDispatchToPropsType={
    signInUser:(user:userTypeSignIn)=>void
 
}


let mapStateToProps = (state:AppStateType):initialStateType=> {

    return  state.authorization

}


export default   connect<initialStateType, MapDispatchToPropsType, {}, AppStateType>(mapStateToProps, {signInUser})(SignIn);