import {getPlayerDataLast, getPlayerDataPrev} from '../../../../../../api/apiNHL'

export const getPlayersLevel= async (roster:any)=>{
    var forwards:number = 0
    var goalkeepers:number = 0
    var defencemans:number = 0
    for(let i=0; i<roster.length; i++){
        
        if(roster[i].position.code==='L' || roster[i].position.code==='R' || roster[i].position.code==='C')
        {
           
           let playerStatisticLast:any  = await getPlayerDataLast(roster[i].person.id)
           let playerStatisticPrev = await getPlayerDataPrev(roster[i].person.id)
           let getPlayersLevelLast:any =playerStatisticLast.data.stats[0].splits[0]&&playerStatisticLast.data.stats[0].splits[0].stat.games>8? (playerStatisticLast.data.stats[0].splits[0].stat.points/playerStatisticLast.data.stats[0].splits[0].stat.games) +
           ((playerStatisticLast.data.stats[0].splits[0].stat.plusMinus/playerStatisticLast.data.stats[0].splits[0].stat.games)*0.5) +
           ((playerStatisticLast.data.stats[0].splits[0].stat.blocked/playerStatisticLast.data.stats[0].splits[0].stat.games)*0.2):0
           let getPlayersLevelPrev:any =playerStatisticPrev.data.stats[0].splits[0]&&playerStatisticPrev.data.stats[0].splits[0].stat.games>8? (playerStatisticPrev.data.stats[0].splits[0].stat.points/playerStatisticPrev.data.stats[0].splits[0].stat.games) +
           ((playerStatisticPrev.data.stats[0].splits[0].stat.plusMinus/playerStatisticPrev.data.stats[0].splits[0].stat.games)*0.5) +
           ((playerStatisticPrev.data.stats[0].splits[0].stat.blocked/playerStatisticPrev.data.stats[0].splits[0].stat.games)*0.2):0
           let getPlayersLevel:any=(getPlayersLevelLast * 0.75) + (getPlayersLevelPrev*0.25)
           roster[i].person.level = (getPlayersLevel.toFixed(3))*100
           forwards = forwards + (getPlayersLevel.toFixed(3))*100
        }
        else if(roster[i].position.code==='D'){
            
            let playerStatisticLast:any  = await getPlayerDataLast(roster[i].person.id)
            let playerStatisticPrev = await getPlayerDataPrev(roster[i].person.id)
            let getPlayersLevelLast:number|any = playerStatisticLast.data.stats[0].splits[0]&&playerStatisticLast.data.stats[0].splits[0].stat.games>8?(playerStatisticLast.data.stats[0].splits[0].stat.points/playerStatisticLast.data.stats[0].splits[0].stat.games) +
            (playerStatisticLast.data.stats[0].splits[0].stat.plusMinus/playerStatisticLast.data.stats[0].splits[0].stat.games) +
            ((playerStatisticLast.data.stats[0].splits[0].stat.blocked/playerStatisticLast.data.stats[0].splits[0].stat.games)*0.2):0
            let getPlayersLevelPrev:number|any = playerStatisticPrev.data.stats[0].splits[0]&&playerStatisticPrev.data.stats[0].splits[0].stat.games>8?(playerStatisticPrev.data.stats[0].splits[0].stat.points/playerStatisticPrev.data.stats[0].splits[0].stat.games) +
            (playerStatisticPrev.data.stats[0].splits[0].stat.plusMinus/playerStatisticPrev.data.stats[0].splits[0].stat.games) +
            ((playerStatisticPrev.data.stats[0].splits[0].stat.blocked/playerStatisticPrev.data.stats[0].splits[0].stat.games)*0.2):0
            let getPlayersLevel:any=(getPlayersLevelLast * 0.75) + (getPlayersLevelPrev*0.25)
            roster[i].person.level = (getPlayersLevel.toFixed(3))*100
            defencemans = defencemans + (getPlayersLevel.toFixed(3))*100
        }
        else if(roster[i].position.code==='G'){
            
            let playerStatisticLast:any = await getPlayerDataLast(roster[i].person.id)
            let playerStatisticPrev = await getPlayerDataPrev(roster[i].person.id)
            let getPlayersLevelLast:number = playerStatisticLast.data.stats[0].splits[0]&&playerStatisticLast.data.stats[0].splits[0].stat.games>8? playerStatisticLast.data.stats[0].splits[0].stat.savePercentage - 0.85:0
            let getPlayersLevelPrev:number = playerStatisticPrev.data.stats[0].splits[0]&&playerStatisticPrev.data.stats[0].splits[0].stat.games>8? playerStatisticPrev.data.stats[0].splits[0].stat.savePercentage - 0.85:0
            let getPlayersLevel:number|any=(getPlayersLevelLast * 0.75) + (getPlayersLevelPrev*0.25)
            roster[i].person.level = (getPlayersLevel.toFixed(3))*1000
            goalkeepers = goalkeepers + (getPlayersLevel.toFixed(3))*1000
        }
       
    }
    return {
        roster,
        forwards,
        defencemans,
        goalkeepers
    }

}