const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let EquipmentSchema = new Schema({
    Process: {
        type: String,
        required:true
    },
    Equipment:{
        type:String,
       
    },
    ['Minimal cross section']:{
        type:Number,
        required:true
    },
    ['Maximal cross section']:{
        type:Number,
        required:true
    },
    Splice:{
        type:String,
        required:true
    },
    Contact:{
        type:String,
        required:true
    },
    Note:{
        type:String,
        required:true
    }
    

}, {
    collection: 'Equipment'
})

module.exports = mongoose.model('Equipment', EquipmentSchema)