import "antd/dist/antd.less";
import "antd/dist/antd.css";
import "./index.css";
import { Row } from "antd";
import {getNeededKoef} from '../../../Components/Equipment Engineering/Components/selectors/getNeededKoef'
import { getPlayersLevel } from '../../../Components/Equipment Engineering/Components/selectors/getPlayersLevel'
import {  getTeamRoster } from "../../../../../api/apiNHL";
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";

import TeamSelected from "./TeamSelected";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import { Progress, Tooltip } from 'antd';

import LinearProgress from '@mui/material/LinearProgress';
import Typography from "@mui/material/Typography";
type PropsType={
  team1:number
  team2:number
}
const MainCombinations: React.FC<PropsType> = ({team1, team2}) => {
  const [selectedTeams, setSelectedTeams]=useState<{team1:number, team2:number}>({
    team1,
    team2
  })
   console.log('team is ' + team1)
 
  const [roster, setRoster] = useState<Array<object>>([{}]);
  const [roster2, setRoster2] = useState<Array<object>>([{}]);
  const [defender, setDefender] = useState<number>(0);
  const [goalkeeper, setGoalkeeper] = useState<number>(0);
  const [forward, setForward] = useState<number>(0);
  const [defender2, setDefender2] = useState<number>(0);
  const [goalkeeper2, setGoalkeeper2] = useState<number>(0);
  const [isLoading, setIsLoading]=useState<boolean>(false)
  const [forward2, setForward2] = useState<number>(0);
  const onChangeTeam = async(prop: string, teamId:number) =>  {
    setIsLoading(true)
       getTeamRoster(teamId).then(async (res) => {
         let response: any = await getPlayersLevel(res.data.roster);
        
         if (prop === "roster") {
           setSelectedTeams({...selectedTeams, team1:teamId})
           setRoster(response.roster);
           setForward(response.forwards);
           setDefender(response.defencemans);
           setGoalkeeper(response.goalkeepers);
         } else if (prop === "roster2") {
           setSelectedTeams({...selectedTeams, team2:teamId})
        
           setRoster2(response.roster);
           setForward2(response.forwards);
           setDefender2(response.defencemans);
           setGoalkeeper2(response.goalkeepers);
         }
         setIsLoading(false)
       });
      
     };
  useEffect(() => {
   onChangeTeam('roster', team1)
   onChangeTeam('roster2', team2)
  
  }, [team1, team2]);
  let team1Possibility:number|any = (((defender+goalkeeper+forward)/((defender+goalkeeper+forward) + (defender2+goalkeeper2+forward2)))*100).toFixed(1)
  let koef:number = getNeededKoef(team1Possibility)
 
if(!isLoading){
  return (
    <Box>
      <Tooltip title={'acceptable koef fora(0) is ' + koef.toFixed(1)}>
      <Progress
      style={{width:'50vw', marginLeft:'10vw', marginBottom:'2vw'}}
        percent={team1Possibility}
        success={{
          percent: team1Possibility,
        }}
       
      />
    </Tooltip>
      <Grid container spacing={2}>
        <Card
          style={{
            width: "25vw",
            marginLeft: "5vw",
            border: "1px solid silver",
          }}
        >
        
          <Row style={{ width: "50vw" }}>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Goalkeepers
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {goalkeeper.toFixed(1)}
              </Typography>
            </Card>

            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Deffenders
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {defender.toFixed(1)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Forwards
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {forward.toFixed(1)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Team2
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {(goalkeeper + defender + forward).toFixed(1)}
              </Typography>
            </Card>
          </Row>

          <TeamSelected roster={roster} />
        </Card>
        <Card
          style={{
            width: "25vw",
            marginLeft: "5vw",
            border: "1px solid silver",
          }}
        >
         
          <Row style={{ width: "50vw" }}>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Goalkeepers
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {goalkeeper2.toFixed(1)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Deffenders
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {defender2.toFixed(1)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Forwards
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {forward2.toFixed(1)}
              </Typography>
            </Card>
            <Card
              style={{
                width: "5vw",
                marginLeft: "1vw",
                marginBottom: "1vw",
                marginTop: "1vw",
              }}
            >
              <Typography
                sx={{ fontSize: "0.75vw" }}
                color="text.secondary"
                gutterBottom
              >
                Teams
              </Typography>
              <Typography sx={{ fontSize: "1.5vw" }} variant="h5" component="div">
                {(goalkeeper2 + defender2 + forward2).toFixed(1)}
              </Typography>
            </Card>
          </Row>

          <TeamSelected roster={roster2} />
        </Card>
      </Grid>
    </Box>
  );
}
else{
  return   (<Box sx={{ width: '70%', marginLeft:'15%' }}>
  <LinearProgress />
</Box>)
}
};
export default React.memo(MainCombinations);
