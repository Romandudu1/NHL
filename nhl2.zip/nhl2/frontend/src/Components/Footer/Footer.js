import * as React from 'react';
import Box from '@mui/material/Box';
import {ThemeProvider, createTheme } from '@mui/material/styles';
import Divider from '@mui/material/Divider';


import Paper from '@mui/material/Paper';


import logo from '../../leoni_logo.png'
import Typography from '@mui/material/Typography';


  
  const Footer=(props)=>{

    return (
       
      <Box color='paper' sx={{ maxWidth: 4500, height: 360 }}>
           <Divider>

        </Divider>
        <ThemeProvider
          theme={createTheme({
            components: {
              MuiListItemButton: {
                defaultProps: {
                  disableTouchRipple: true,
                },
              },
            },
            palette: {
              mode: 'dark',
              primary: { main: 'rgba(71, 98, 130, 0.2)' },
              background: { paper: 'rgba(56,56,56,1)' },
            },
          })}
        >
          <Paper elevation={10} sx={{ maxWidth: '350vw', height: '25vw'}}>
             <img style={{marginLeft:'41vw', height:'2vw', marginTop:'5vw'}} alt="logo" src={logo} />
             <Typography style={{marginLeft:'44vw', fontSize:'1vw', marginTop:'1vw'}} variant="h5" gutterBottom component="div">
          
            All rights reserved 2022
          </Typography>
          </Paper>
          
        </ThemeProvider>
      </Box>
    );
  }

export default React.memo(Footer)