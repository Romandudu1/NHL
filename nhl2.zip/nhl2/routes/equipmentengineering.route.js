let mongoose = require('mongoose'),
    express = require('express'),
    router = express.Router();

let bodyParser = require('body-parser')


const excel = require('exceljs');
var urlencodedParser = bodyParser.urlencoded({ extended: false });








router.route('/getLastUpdated').get(urlencodedParser, async (req, res) => {
    try {

        let arrayOfAdded = await InventorySchema.find({}).sort({ addedTime: -1 }).limit(4)
        let arrayOfInserted = await InventorySchema.find({ quantity: { $ne: '' } })
        let totalOfProperties = await InventorySchema.find({})
        let percentage = parseFloat((arrayOfInserted.length / totalOfProperties.length) * 100).toFixed(1)

        var item = {
            percentage,
            arrayOfAdded
        }
        res.json(item)
    }
    catch (e) {
        res.json(e.message)
    }


})


router.route('/addPositionToInventory').post(urlencodedParser, async (req, res) => {
    try {
        let { code, quantity, addedBy } = req.body.data
        let existingOfCode = await InventorySchema.updateOne({ scan: code }, { quantity, addedBy, addedTime: new Date() })

        let arrayOfAdded = await InventorySchema.find({}).sort({ addedTime: -1 }).limit(4)
        let responseItem = {
            modified: existingOfCode.modifiedCount,
            lastUpdates: arrayOfAdded
        }
        res.json(responseItem)
    }
    catch (e) {
        res.json(e.message)
    }


})

router.route('/getEquipmentToExcel').post(urlencodedParser, async (req, res, next) => {

    try {
        var data = await EquipmentSchema.find({})
        let workbook = new excel.Workbook()
        let worksheet = workbook.addWorksheet('Equipment')
        worksheet.columns = [
            { header: 'Процес', key: 'Process', width: 10 },
            { header: 'Обладнання', key: 'Equipment', width: 30 },
            { header: 'Мінімальний переріз', key: 'Minimal cross section', width: 30 },
            { header: 'Максимальний переріз', key: 'Maximal cross section', width: 30 },
            { header: 'Сплайс', key: 'Splice', width: 30 },
            { header: 'Контакт', key: 'Contact', width: 30 },
            { header: 'Примітка', key: 'Note', width: 30 },

        ];
        const os = require('os');
        var user = os.userInfo();
        worksheet.addRows(data)
        var routeForSaving = '\\\\leoni.local\\dfsroot\\UA1\\groups\\Austausch\\All_Deps\\instruction\\'
        var FileNames = 'equipment ' + Math.floor(Math.random() * 10000)
        await workbook.xlsx.writeFile(routeForSaving + FileNames + ".xlsx")
            .then(function () {

            });
        res.status(200).json('ok')
    }
    catch (e) {
        res.status(200).json(e.message)
    }


})







module.exports = router;
