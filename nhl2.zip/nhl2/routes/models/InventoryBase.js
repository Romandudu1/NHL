const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let InventorySchema = new Schema({
    position: {
        type: Number,
        required:true
    },
    place:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
       },

   kanban:{
    type:String,
  
   },
   
   ag:{
    type:String
   },

   scan:{
       type:String,
       required:true
   },

   quantity:{
       type:Number
   },
   
   addedBy:{
       type:String,
   },

   addedTime:{
       type:Date
   }
    


   
    

}, {
    collection: 'Inventory'
})

module.exports = mongoose.model('Inventory', InventorySchema)