import  axios from 'axios';
//import jwt_decode from "jwt-decode";
import {userType, userTypeSignIn} from "../redux/reducers/authReducer";
//var token = localStorage.getItem('jwt')
//var decoded = token?jwt_decode(token):'';
 //console.log(decoded.name)
//import unsplash from 'unsplash-js'
export const  instance = axios.create({
    baseURL:'http://localhost:4000/auth/',

})

/*type UserType={
    firstName: string
    lastName:string
    department:string
    position:string
    email:string
    password:string
    getEmails:string
        
}*/

type createUserType={

    user:userType,
    message:string,
    isAuth:boolean,
    token:string
}


type uniqueEmailType={
    uniqueEmail:boolean
}

/*type signInType={
    data:createUserType
}*/

    

export  const  setUserApi=(userObject:userType)=>{
    
        return instance.post<createUserType>('/create-user', {userObject}).then(res=>{
            return res.data
        })
        }

        export  const  checkEmailApi=(email:string)=>{
         
            return instance.post<uniqueEmailType>('/checkEmail', {email}) }
            
            export  const  getUsers=()=>{
         
                return instance.get('/getUsers')}


export  const  signInUserApi=(userObject:userTypeSignIn)=>{

    return instance.post<createUserType>('/signIn', {userObject})
}



