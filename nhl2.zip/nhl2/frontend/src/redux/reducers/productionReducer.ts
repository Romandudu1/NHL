import { checkIfExistInUssApi, addOneCombinationApi, deleteWireApi,  deleteCombinationApi, deleteFromInstructionWireApi, addWireToEquipmentApi, editFromInstructionWireApi } from "../../api/productionApi";
//import jwt_decode from "jwt-decode";
import { Dispatch } from "redux";
//import {stopSubmit, reset} from "redux-form";
//var token = localStorage.getItem('jwt')
//var decoded = token ? jwt_decode(token) : '';
type oneCombinationType = {
    typeofConnection: string
    project: string
    requestor: string
    location: string
    assigned: string
    deadline: Date
    comments: string
    combination: string
    crossSectionCombination: number
    isValidCombination: boolean
}
type actionType = addListCreatorType | existCombinationCreatorType | addOneCombinationCreatorType | deleteWireCreatorType | deleteWireFromInstructionCreatorType | editWireFromInstructionCreatorType | addOneEquipmentCreatorType|addWireToInstructionCreatorType|defaultReleaseMessageCreatorType|deleteCombinationCreatorType
export type dataObjectType = {
    project: string | null
    location: string | null
    assigned: string | null
    deadline: string | null
}
export type initialStateType = {
    stream: string | null
    combinationExist: boolean
    dataObject: dataObjectType
    releasedCombination: releasedCombinationType
    addedToReleaseMessage: String
}

export type releasedCombinationType = {
    'Загальний переріз': string
    'Опис комбінацій': string
    'Опис_комбінації_10%': string
    'Druck /  Тиск': string
    'Druck_10%': string
    'Breite / Ширина': string
    'Breite_10%': string
    'Amplitude/Амплітуда': string
    'Amplitude_10%': string
    'Amplitude_-10%': string
    'Energie/Енергія': string
    'Energie_10%': string
    'Data/Дата затвердження': string
    '№ програми': string
    equipment: string


}

let initialstate: initialStateType = {
    stream: '',
    combinationExist: false,
    releasedCombination: {
        'Загальний переріз': '',
        'Опис комбінацій': '',
        'Опис_комбінації_10%': '',
        'Druck /  Тиск': '',
        'Druck_10%': '',
        'Breite / Ширина': '',
        'Breite_10%': '',
        'Amplitude/Амплітуда': '',
        'Amplitude_10%': '',
        'Amplitude_-10%': '',
        'Energie/Енергія': '',
        'Energie_10%': '',
        'Data/Дата затвердження': '',
        '№ програми': '',
        equipment: ''
    },
    dataObject: {
        project: '',
        location: '',
        assigned: '',
        deadline: ''

    },

    addedToReleaseMessage: ''
};


export const productionReducer = (state = initialstate, action: any) => {
    switch (action.type) {
        case "ADDLIST":

            return {
                ...state, user: action.user, message: action.message, isAuth: true
            }

        case "ADDONE":

            return {
                ...state, addedToReleaseMessage: action.message
            }
        case "EXISTCOMBINATION":
          
            return {
                ...state, combinationExist: action.combinationExist, releasedCombination: action.releasedCombination
            }

        case "DELETEWIRE":

            return {
                ...state, addedToReleaseMessage: 'deleted value'
            }

            case "DELETECOMBINATION":

            return {
                ...state, addedToReleaseMessage: 'deleted value'
            }



        case "DELETEWIREFROMINSTRUCTION":

            return {
                ...state, addedToReleaseMessage: 'deleted value'
            }

        case "EDITWIREFROMINSTRUCTION":

            return {
                ...state, addedToReleaseMessage: 'deleted value'
            }

            case "ADDWIRETOINSTRUCTION":
                
            return {
                ...state, addedToReleaseMessage: 'added to instruction'
            }

            case "DEFAULTRELEASEMESSAGE":

                return {...state, addedToReleaseMessage: 'not added'};

        default:
          
            return {...state, addedToReleaseMessage: 'not added'};
    }
}
//delete WireType

const DELETEWIRE = "DELETEWIRE"
type deleteWireCreatorType = {
    type: typeof DELETEWIRE
}

export const deleteWireCreator = (): deleteWireCreatorType => {
    return {
        type: "DELETEWIRE"
    }
}

export const deleteWire = (wires: Array<Object>) => (dispatch: Dispatch<actionType>) => {
    deleteWireApi(wires).then(res => {
        dispatch(deleteWireCreator())
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}


//delete Combination

const DELETECOMBINATION = "DELETECOMBINATION"
type deleteCombinationCreatorType = {
    type: typeof DELETECOMBINATION
}

export const deleteCombinationCreator = (): deleteCombinationCreatorType => {
    return {
        type: "DELETECOMBINATION"
    }
}

export const deleteCombination = (wires: Array<Object>) => (dispatch: Dispatch<actionType>) => {
    deleteCombinationApi(wires).then(res => {
        dispatch(deleteCombinationCreator())
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}


//delete WireTypeFromInstruction

const DELETEWIREFROMINSTRUCTION = "DELETEWIREFROMINSTRUCTION"
type deleteWireFromInstructionCreatorType = {
    type: typeof DELETEWIREFROMINSTRUCTION
}

export const deleteWireFromInstructionCreator = (): deleteWireFromInstructionCreatorType => {
    return {
        type: "DELETEWIREFROMINSTRUCTION"
    }
}
type WireFromInstructionType = {
    key: Number,
    wireTypeInstruction: String,
    reducingKanbanInstruction: String,
    reducingShrinkingInstruction: String,
    crossSectionInstruction: String

}
export const deleteWireFromInstruction = (wires: WireFromInstructionType) => (dispatch: Dispatch<actionType>) => {
   
    deleteFromInstructionWireApi(wires).then(res => {
        dispatch(deleteWireCreator())
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}


//edit WireTypeFromInstruction

const EDITWIREFROMINSTRUCTION = "EDITWIREFROMINSTRUCTION"
type editWireFromInstructionCreatorType = {
    type: typeof EDITWIREFROMINSTRUCTION
}

export const editWireFromInstructionCreator = (): editWireFromInstructionCreatorType => {
    return {
        type: "EDITWIREFROMINSTRUCTION"
    }
}

export const editWireFromInstruction = (wire: WireFromInstructionType, edited: WireFromInstructionType) => (dispatch: Dispatch<actionType>) => {
  
    editFromInstructionWireApi(wire, edited).then(res => {
        dispatch(editWireFromInstructionCreator())
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}

//add WireTypeFromInstruction

const ADDWIRETOINSTRUCTION = "ADDWIRETOINSTRUCTION"
type addWireToInstructionCreatorType = {
    type: typeof ADDWIRETOINSTRUCTION
}

export const addWireToInstructionCreator = (): addWireToInstructionCreatorType => {
    return {
        type:"ADDWIRETOINSTRUCTION"
    }
}

export const addWireToInstruction = () => (dispatch: Dispatch<actionType>) => {
  
       
        dispatch(addWireToInstructionCreator())
   
        

}

//add Default Release message

const DEFAULTRELEASEMESSAGE= "DEFAULTRELEASEMESSAGE"
type defaultReleaseMessageCreatorType = {
    type: typeof DEFAULTRELEASEMESSAGE
}

export const defaultReleaseMessageCreator = (): defaultReleaseMessageCreatorType => {
    return {
        type:"DEFAULTRELEASEMESSAGE"
    }
}

export const defaultReleaseMessage = () => (dispatch: Dispatch<actionType>) => {
  
        
        dispatch(defaultReleaseMessageCreator())
   
        

}


//ADD List CREATOR
const ADDLIST = "ADDLIST"
type addListCreatorType = {
    type: typeof ADDLIST
    dataCombinations: string
    message: string
}
export const addListCreator = (dataCombinations: string, message: string): addListCreatorType => {
    return {
        type: "ADDLIST",
        dataCombinations,
        message: message
    }
}

//Check if Combination Exist
const EXISTCOMBINATION = "EXISTCOMBINATION"
type existCombinationCreatorType = {
    type: typeof EXISTCOMBINATION,
    combinationExist: boolean,
    releasedCombination: releasedCombinationType
}

export const existCombinationCreator = (combinationExist: boolean, releasedCombination: releasedCombinationType): existCombinationCreatorType => {
    return {
        type: "EXISTCOMBINATION",
        combinationExist,
        releasedCombination
    }
}



export const existCombination = (combination: string) => (dispatch: Dispatch<actionType>) => {
    checkIfExistInUssApi(combination).then(res => {
        
        dispatch(existCombinationCreator(res.data.existingCombination, res.data.combination))
    })
        .catch(error => {
            alert(error.response.data.message)

        })
}

//Add one Equipment Engineering
const ADDONEEQUIPMENT = "ADDONEEQUIPMENT"
type addOneEquipmentCreatorType = {
    type: typeof ADDONEEQUIPMENT,
    message: String
    data: Object
}

type addOneEquipmentType = {
    key: Number,
    user: String,
    project: String,
    location: String,
    equipment: String,
    combination: String,
    crossSection: Number,
    program: Number
}


export const addOneEquipmentCreator = (data: addOneEquipmentType, message: String): addOneEquipmentCreatorType => {
    return {
        type: 'ADDONEEQUIPMENT',
        data,
        message

    }
}



export const addOneEquipment = (data: Array<addOneEquipmentType>) => (dispatch: Dispatch<actionType>) => {

    addWireToEquipmentApi(data).then(res => {
        
        dispatch(addOneCombinationCreator(res.data.combination, res.data.message))
    })
        .catch(error => {
            alert(error.response.data.message)

        })
}



//add One Combination

const ADDONE = "ADDONE"
type addOneCombinationCreatorType = {
    type: typeof ADDONE,
    message: String
    data: Object
}
export const addOneCombinationCreator = (data: oneCombinationType, message: String): addOneCombinationCreatorType => {
    return {
        type: 'ADDONE',
        data,
        message

    }
}



export const addOneCombination = (data: oneCombinationType) => (dispatch: Dispatch<actionType>) => {
   
    addOneCombinationApi(data).then(res => {
      
        dispatch(addOneCombinationCreator(res.data.combination, res.data.message))
    })
        .catch(error => {
            alert(error.response.data.message)

        })
}
//ADD LIST FUNCTION
/*export  const addList=(fileContent:any, dataObject:any )=>(dispatch:any)=>{
   
    addListCombinationsApi(fileContent, dataObject).then(res=>{
        console.log(Object.getOwnPropertyNames(res) + res.data.user.name)
        localStorage.setItem('jwt', res.data.token)
   dispatch(addListCreator(res.data.user, res.message))})
   .catch(error=>{
       console.log(error.response.data.message)
    alert(error.response.data.message)
   
})
}*/




