import  axios from 'axios';

//import unsplash from 'unsplash-js'
export const  instance = axios.create({
    baseURL:'http://localhost:4000/production/',
    
})

export  const  editFromInstructionWireApi=(wire, edited)=>{
   
    return instance.post('/editWireFromInstruction', {wire, edited}) }


    export  const  addWireToEquipmentApi=(wire)=>{
   
  return instance.post('/addWireToEquipment', {wire}) }


export  const  deleteFromInstructionWireApi=(wires)=>{
   
    return instance.post('/deleteWireFromInstruction', {wires}) }

export  const  deleteWireApi=(wires)=>{
   
return instance.post('/deleteWire', {wires}) }

export  const  deleteCombinationApi=(wires)=>{
   
    return instance.post('/deleteCombination', {wires}) }

export  const  AddWireApi=(wires)=>{
   
    return instance.post('/addWire', {wires}) }

export  const  addOneCombinationApi=(data)=>{
         console.log('api project is ' + data.project)
    return instance.post('/AddOne', {data}) }

    export  const  getInstructionWires=()=>{
         
    return instance.get('/getInstruction')}

    export  const  getCombinationsRequests=()=>{
         
        return instance.get('/getCombinationsRequests')}

        export  const  getInstructionWiresExist=()=>{
         
            return instance.get('/getInstructionExist')}

            export  const  getEquipmentProcessExist=()=>{
         
                return instance.get('/getEquipmentProcessExist')}

export  const  addCombinationsApi=(fileContent, data)=>{
         
    return instance.post('/Add List', {fileContent, data}) }

    export  const  checkIfExistInUssApi=(combination)=>{
         
        return instance.post('/existInUssBase', {combination}) }

    export  const  getTypesAndCrossSections=()=>{
         
        return instance.get('/getTypesAndCrossSections')}

        export  const getAddInstructionWires=()=>{
         
            return instance.get('/getAddInstructionWires')}
            export  const  releaseCombination=(cominationObject)=>{
            
                 
                return instance.post('/releaseCombination', {cominationObject})}

        export  const  AddInstruction=(addInstructionObject)=>{
            
            /*var token = localStorage.getItem('jwt')
            var decoded = token?jwt_decode(token):'';
        
             addInstructionObject.requestor=decoded.name*/
            return instance.post('/addInstruction', {addInstructionObject})}

            export const getInstructionToExcel=()=>{
                return instance.post('/getInstructionToExcel', {})
            }