
import React from 'react';
import Header from './Components/Header/Header'
import ContentContainer from './Components/Content/ContentContainer'
import {BrowserRouter} from 'react-router-dom';
import store  from './redux/redux-store';
import {Provider} from 'react-redux';
//import Footer from './Components/Footer/Footer'
import {AppStateType} from './redux/redux-store'


const  App:React.FC<AppStateType> = (props)=>{
  
  return (
    <Provider  store={store}>
    <BrowserRouter>
    <div className="App">
    <Header />
    <ContentContainer />
   {/* <Footer />*/}
    </div>
    
    </BrowserRouter>

    </Provider>
  );
}

export default App;
