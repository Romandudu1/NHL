
import { addEquipmentApi, deleteEquipmentApi, getRequestsToStatus, addRequestToQualityApi,  getRequestsToEquipment } from '../../api/equipmentApi'
//import jwt_decode from "jwt-decode";
import { Dispatch } from "redux";
//import {stopSubmit, reset} from "redux-form";
//var token = localStorage.getItem('jwt')
//var decoded = token ? jwt_decode(token) : '';

type actionType = addEquipmentCreatorType | deleteEquipmentCreatorType | addRequestToQualityCreatorType | getEquipmentRequestsCreatorType|getStatusRequestsCreatorType



let itemInitialState: AddRequestToQualityType = {
    combination: '',
    crossSection: 0,
    program: 0,
    equipment: '',
    user: '',
    technik:'',
    dateOfAdding: '',
    pressure: 0,
    width: 0,
    amplitude: 0,
    energie: 0,
    commentsShlifbild: '',
    commentsZryv: '',
    statusShlifbild: '',
    statusZryv: '',
    project: '',
    location: '',
    assigned: '',
    typeOfConnection: '',
    deadline: '', 
    imageShlifbild:'',
};

let initialstate = [ itemInitialState ]

export const equipmentReducer = (state = initialstate, action: any) => {
    switch (action.type) {



        case "EXISTCOMBINATION":

            return {
                ...state, combinationExist: action.combinationExist, releasedCombination: action.releasedCombination
            }

        case "ADDEQUIPMENT":

            return {
                ...state, addedToReleaseMessage: 'equipment added'
            }

       

        

        case "ADDREQUESTTOQUALITY":


            return {
                ...state, equipmentRequests: action.requests.combination, addedToReleaseMessage: 'request added'
            }

        case "DELETEEQUIOMENT":

            return {
                ...state, addedToReleaseMessage: 'deleted equipment'
            }
        
        case "GETEQUIPMENTREQUESTS":

            {

                return action.equipmentRequests
            }
           case "GETSTATUSREQUESTS":
      
               
               {
                return action.statusRequests.data

           }






        default: return state






    }

}






//get Equipment Requests

const GETEQUIPMENTREQUESTS = "GETEQUIPMENTREQUESTS"
type getEquipmentRequestsCreatorType = {
    type: typeof GETEQUIPMENTREQUESTS,
    equipmentRequests: Array<Object>

}

export const getEquipmentRequestsCreator = (equipmentRequests: Array<Object>): getEquipmentRequestsCreatorType => {
    return {
        type: "GETEQUIPMENTREQUESTS",
        equipmentRequests
    }
}




export const getEquipmentRequest = () => (dispatch: Dispatch<actionType>) => {
    console.log('getting equipment!!!')
    getRequestsToEquipment().then(res => {

        dispatch(getEquipmentRequestsCreator(res.data))
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}


//get Status Requests

const GETSTATUSREQUESTS = "GETSTATUSREQUESTS"
type getStatusRequestsCreatorType = {
    type: typeof GETSTATUSREQUESTS,
    statusRequests: Array<Object>

}

export const getStatusRequestsCreator = (statusRequests: Array<Object>): getStatusRequestsCreatorType => {
    return {
        type: "GETSTATUSREQUESTS",
        statusRequests
    }
}




export const getStatusRequest = (user:String) => (dispatch: Dispatch<actionType>) => {
   
    getRequestsToStatus(user).then(res => {
         debugger;
         console.log(res.data.length)
        dispatch(getStatusRequestsCreator(res.data))
    })
        .catch(error => {
            alert(error)

        })

}




//delete Equipment

const DELETEEQUIPMENT = "DELETEEQUIPMENT"
type deleteEquipmentCreatorType = {
    type: typeof DELETEEQUIPMENT
}

export const deleteEquipmentCreator = (): deleteEquipmentCreatorType => {
    return {
        type: "DELETEEQUIPMENT"
    }
}

export const deleteEquipment = (equipment: Object) => (dispatch: Dispatch<actionType>) => {
    deleteEquipmentApi(equipment).then(res => {
        dispatch(deleteEquipmentCreator())
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}




//add Equipment
type AddEquipmentType = {
    Process: String,
    Equipment: String,
    ['Minimal cross section']: String,
    ['Maximal cross section']: String,
    Splice: String,
    Contact: String,
    Note: String,
}
const ADDEQUIPMENT = "ADDEQUIPMENT"
type addEquipmentCreatorType = {
    type: typeof ADDEQUIPMENT
}

export const addEquipmentCreator = (): addEquipmentCreatorType => {
    return {
        type: "ADDEQUIPMENT"
    }
}

export const addEquipment = (equipment: AddEquipmentType) => (dispatch: Dispatch<actionType>) => {

    addEquipmentApi(equipment).then(res => {
        dispatch(addEquipmentCreator())
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}

//add Request to Quality
type AddRequestToQualityType = {
    combination: String,
    crossSection: Number,
    program: Number,
    equipment: String,
    technik:String,
    user: String,
    dateOfAdding: String,
    pressure: Number,
    width: Number,
    amplitude: Number,
    energie: Number,
    commentsShlifbild: String,
    commentsZryv: String,
    statusShlifbild: String,
    statusZryv: String,
    project: String,
    location: String,
    deadline: String,
    typeOfConnection: String,
    assigned: String,
    imageShlifbild:String,
}
const ADDREQUESTTOQUALITY = "ADDREQUESTTOQUALITY"
type addRequestToQualityCreatorType = {
    type: typeof ADDREQUESTTOQUALITY,
    requests: Array<Object>
}

export const addRequestToQualityCreator = (requests: Array<AddRequestToQualityType>): addRequestToQualityCreatorType => {
    return {
        type: "ADDREQUESTTOQUALITY",
        requests
    }
}

export const addRequestToQuality = (request: AddRequestToQualityType) => (dispatch: Dispatch<actionType>) => {

    addRequestToQualityApi(request).then(res => {
        dispatch(addRequestToQualityCreator(res.data))
    })
        .catch(error => {
            alert(error.response.data.message)

        })

}
























