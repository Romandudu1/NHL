const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let CombinationReleaseSchema = new Schema({
    NameOfSender: {
        type: String,
        required:true
    },
     Released:{
    type:Boolean,
    required:true
    },

    DateOfSending:{

        type: String,
        required:true
    },
    TypeOfConnection:
    {
        type: String,
        required:true
    },
    Deadline:{
        type:Date,
        required:true
    },
    Project:{
        type:String,
        required:true
    },
    
    Location:{
        type:String,
        required:true
    }, 

    Assigned:{
        type:String,
        required:true
    },
       
    
    Combination: {
        type: String,
        unique:true,
        required:true
    },
    Comments: {
        type: String
        
    },

    crossSectionCombination: {
        type: Number,
        required:true
        
    },
    Equipment: {
        type: String,
        required:true
        
    },
    ProgrammNumber:{
        type:Number,
        required:true
    },

    commentsShlifbild:{
        type: String,
    },
    commentsZryv:{
        type: String,
    },

    statusShlifbild:{
        type:String
      
    },
    statusZryv:{
        type:String
       
    },
    
    imageShlifbild:{
        type:String
    },

    imageZryv:{
        type:String
      
     },

       



}, {
    collection: 'CombinationRelease'
})

module.exports = mongoose.model('CombinationRelease', CombinationReleaseSchema)