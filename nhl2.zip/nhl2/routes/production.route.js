let mongoose = require('mongoose'),
    express = require('express'),
    router = express.Router();
    var nodemailer = require('nodemailer');

let bodyParser = require('body-parser')
let jwt = require('jsonwebtoken')
let userSchema = require('./models/User')
let TypesCrossSectionSchema = require('./models/TypesCrossSections')
let AddInstructionSchema = require('./models/AddInstruction')
let ussBaseSchema = require('./models/UssBase')
let combinationReleaseSchema = require('./models/CombinationRelease')
let EquipmentEngineeringSchema = require('./models/EquipmentCombination')
let EquipmentSchema = require('./models/Equipment')
let HistorySchema = require('./models/History')
var jsonParser = bodyParser.json()
let bcrypt = require('bcryptjs')
let getEquipment = require('./ProductionEngineering/getEquipment')
const excel = require('exceljs');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var nodeoutlook = require('nodejs-nodemailer-outlook')


// import list Of Combinations
router.route('/Add List').post(urlencodedParser, async (req, res, next) => {
    try {


        res.status(200).json(answer)
    }

    catch (e) {
        console.log('wror is ' + e.stack)
        res.status(404).json('wrong data')
    }

});

router.route('/AddOne').post(async (req, res, next) => {
    try {

        let { typeofConnection, project, requestor, location, assigned, deadline, comments, combination, crossSectionCombination, isValidCombination } = req.body.data
        const equipmentCombination = await getEquipment.getEquipment(crossSectionCombination, typeofConnection)
        let DateOfSending = Date("03/25/2015")
        var arrayOfCombinations = await combinationReleaseSchema.find({})
        await HistorySchema.create({
           process:typeofConnection,
           combination,
           history:['created by user ' + requestor + ' ' + new Date()] 
        })
        const existingCombination = await combinationReleaseSchema.findOne({ Combination: combination })
        let returnedValue = Math.floor(Math.random() * 10) + 1
        if (existingCombination) return res.status(200).json({ message: returnedValue })
        if (arrayOfCombinations.length === 0) {
            var ProgrammNumber = 3000

        }
        else {
            arrayOfCombinations.sort(function (a, b) {
                return a.Cost - b.Cost
            })
            var max = arrayOfCombinations[arrayOfCombinations.length - 1]

            var ProgrammNumber = parseInt(max.ProgrammNumber + 1)

        }
        const newSavedCombinationRelease = new combinationReleaseSchema({
            NameOfSender: requestor, DateOfSending, 
            TypeOfConnection: typeofConnection, Deadline: deadline, Released: false, Project: project, Location: location, Assigned: assigned, Combination: combination,
            Comments: comments, ProgrammNumber, crossSectionCombination, Equipment: equipmentCombination, commentsShlifbild:'',
            commentsZryv:'', statusShlifbild:'in process', statusZryv:'in process'
        
        })
         
        const savedCombinationRelease = await newSavedCombinationRelease.save()
        if (savedCombinationRelease) {
            res.status(200).json({ message: 'success', combination: savedCombinationRelease })
        }
        else {
            res.status(200).json({ answer: 'error' })
        }

    }

    catch (e) {
        console.log('wror is ' + e.stack)
        res.status(404).json('wrong data')
    }

});



router.route('/addInstruction').post(urlencodedParser, async (req, res, next) => {
    try {

        let { wirePartnumber, wireType, crossSection, requestor } = req.body.addInstructionObject

        const existingCombination = AddInstructionSchema.find({ wireType, crossSection, wirePartnumber })
        if (!existingCombination) return res.status(409).json({ message: "цей тип вже існує в базі затверджень" })
        const newInstruction = new AddInstructionSchema({ wireType, crossSection, wirePartnumber, requestor })
        const savedUser = await newInstruction.save()

        res.status(200).json({ message: 'created successfully' })
    }

    catch (e) {
        console.log(e.message)
        res.status(404).json({ message: 'неправильні вхідні дані' })
    }

});

router.route('/getTypesAndCrossSections').get(urlencodedParser, (req, res) => {

    TypesCrossSectionSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})




router.route('/deleteWire').post(urlencodedParser, (req, res) => {


   // Create the transporter with the required configuration for Outlook
// change the user and pass !
var transporter = nodemailer.createTransport({
    host: "smtp-mail.outlook.com", // hostname
    secureConnection: false, // TLS requires secureConnection to be false
    port: 587, // port for secure SMTP
    tls: {
       ciphers:'SSLv3'
    },
    auth: {
        user: 'Roman.Dudych@leoni.com',
        pass: 'Windows2026r'
    }
});

// setup e-mail data, even with unicode symbols
var mailOptions = {
    from: '"Our Code World " <Roman.Dudych@leoni.com>', // sender address (who sends)
    to: 'Roman.Dudych@leoni.com', // list of receivers (who receives)
    subject: 'Hello ', // Subject line
    text: 'Hello world ', // plaintext body
    html: '<b>Hello world </b><br> This is the first email sent with Nodemailer in Node.js' // html body
};

// send mail with defined transport object
transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
    }

    console.log('Message sent: ' + info.response);
});

    
    AddInstructionSchema.findOneAndRemove({
        wireType: req.body.wires[0].wireType,
        crossSection: req.body.wires[0].crossSection, wirePartnumber: req.body.wires[0].wirePartnumber
    }, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})

router.route('/deleteCombination').post(urlencodedParser, async (req, res) => {

   
    await combinationReleaseSchema.findOneAndDelete({ Combination: req.body.wires[0].combination })
    combinationReleaseSchema.findOneAndRemove({
        Combination: req.body.wires[0].Combination
       
    }, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})



router.route('/deleteWireFromInstruction').post(urlencodedParser, (req, res) => {


    TypesCrossSectionSchema.findOneAndRemove({
        Wire_Type: req.body.wires.wireTypeInstruction,
        ReducingKanBan: req.body.wires.reducingKanbanInstruction, ReducingShrinking: req.body.wires.reducingShrinkingInstruction, CrossSection: req.body.wires.crossSectionInstruction,
    }, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})

router.route('/editWireFromInstruction').post(urlencodedParser, (req, res) => {


    TypesCrossSectionSchema.findOneAndUpdate({
        Wire_Type: req.body.wire.wireTypeInstruction,
        ReducingKanBan: req.body.wire.reducingKanbanInstruction, ReducingShrinking: req.body.wire.reducingShrinkingInstruction, CrossSection: req.body.wire.crossSectionInstruction,
    }, {
        Wire_Type: req.body.edited.wireTypeInstruction,
        ReducingKanBan: req.body.edited.reducingKanbanInstruction, ReducingShrinking: req.body.edited.reducingShrinkingInstruction, CrossSection: req.body.edited.crossSectionInstruction
    }, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})


router.route('/addWire').post(urlencodedParser, async (req, res) => {

    const TypesAndWire = new TypesCrossSectionSchema({
        Wire_Type: req.body.wires[0].wireType,
        ReducingKanBan: (req.body.wires[0].wireType).replace('FL', ''),
        ReducingShrinking: (req.body.wires[0].wireType).replace('FL', ''),
        CrossSection: req.body.wires[0].crossSection
    })
    const savedTypesAndWire = await TypesAndWire.save()
    AddInstructionSchema.findOneAndRemove({
        wireType: req.body.wires[0].wireType,
        crossSection: req.body.wires[0].crossSection, wirePartnumber: req.body.wires[0].wirePartnumber
    }, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {

            res.json(data)
        }
    })
})


router.route('/getAddInstructionWires').get(urlencodedParser, (req, res) => {

    AddInstructionSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {

            res.json(data)
        }
    })
})

router.route('/getInstruction').get(urlencodedParser, (req, res) => {
    AddInstructionSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})

router.route('/getCombinationsRequests').get(urlencodedParser, (req, res) => {
    combinationReleaseSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})


router.route('/getInstructionExist').get(urlencodedParser, (req, res) => {





    TypesCrossSectionSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})


router.route('/getEquipmentProcessExist').get(urlencodedParser, (req, res) => {





    EquipmentSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})






router.route('/getUsers').get(urlencodedParser, (req, res) => {

    userSchema.find({}, (error, data) => {

        if (error) {
            console.log('it was error')
            return next(error)
        } else {
            res.json(data)
        }
    })
})
//Check Combination Existing
router.route('/existInUssBase').post((req, res, next) => {

    ussBaseSchema.findOne({ ['Опис комбінацій']: req.body.combination }).then((combination) => {

        if (combination) {

            res.status(200).json({ existingCombination: true, combination })
        }

        else {
            res.status(200).json({
                existingCombination: false, combination: {
                    'Загальний переріз': '',
                    'Опис комбінацій': '',
                    'Опис_комбінації_10%': '',
                    'Druck /  Тиск': '',
                    'Druck_10%': '',
                    'Breite / Ширина': '',
                    'Breite_10%': '',
                    'Amplitude/Амплітуда': '',
                    'Amplitude_10%': '',
                    'Amplitude_-10%': '',
                    'Energie/Енергія': '',
                    'Energie_10%': '',
                    'Data/Дата затвердження': '',
                    '№ програми': '',
                    equipment: ''

                }
            })
        }
    })

});


router.route('/addWireToEquipment').post(async (req, res, next) => {

     
    let { user, project, location, equipment, combination, program, crossSection, assigned, typeOfConnection, deadline } = req.body.wire[0]
    const newEquipmentCombination = new EquipmentEngineeringSchema({
         deadline, assigned, typeOfConnection, 
        
        'Загальний переріз': crossSection,
        'Опис комбінацій': combination,
        'Druck /  Тиск': '',
        'Druck_10%': '',
        'Breite / Ширина': '',
        'Breite_10%': '',
        'Amplitude/Амплітуда': '',
        'Amplitude_10%': '',
        'Amplitude_-10%': '',
        'Energie/Енергія': '',
        'Energie_10%': '',
        'Data/Дата затвердження': '',
        '№ програми': program,
        equipment,
        user,
        location,
        project,
        dateOfAdding: Date(),
        commentsShlifbild:'',
        commentsZryv:'',
        statusShlifbild:'in process',
        statusZryv:'in process'
        
    })
    
     previousHistory = await HistorySchema.find({process:typeOfConnection, combination})
    
   
    let historyBefore = await previousHistory[0].history
  
    
     await  historyBefore.push('released by Cutting Engineering and given samples by ' + user + ' ' + new Date())
   
    await HistorySchema.findOneAndUpdate(
        {process:typeOfConnection,
        combination},
        {history:historyBefore}
     )
    const savedEquipmentEngineering = await newEquipmentCombination.save()
    await combinationReleaseSchema.findOneAndDelete({ Combination: combination })
    EquipmentEngineeringSchema.findOne({ ['Опис комбінацій']: combination }).then((combination) => {

        if (combination) {

            res.status(200).json({ existingCombination: true, combination })
        }

        else {
            res.status(200).json({
                existingCombination: false, combination: {
                    'Загальний переріз': '',
                    'Опис комбінацій': combination,
                    'Опис_комбінації_10%': '',
                    'Druck /  Тиск': '',
                    'Druck_10%': '',
                    'Breite / Ширина': '',
                    'Breite_10%': '',
                    'Amplitude/Амплітуда': '',
                    'Amplitude_10%': '',
                    'Amplitude_-10%': '',
                    'Energie/Енергія': '',
                    'Energie_10%': '',
                    'Data/Дата затвердження': '',
                    '№ програми': '',
                    equipment,
                    user,
                    location,
                    project,
                    dateOfAdding: ''
                }
            })
        }
    })

});


router.route('/getInstructionToExcel').post(urlencodedParser, async (req, res, next) => {

    try {
        var data = await TypesCrossSectionSchema.find({})
        let workbook = new excel.Workbook()
        let worksheet = workbook.addWorksheet('Instruction')
        worksheet.columns = [
            { header: 'Wire Type', key: 'Wire_Type', width: 10 },
            { header: 'Скорочення Канбан', key: 'ReducingKanBan', width: 30 },
            { header: 'Скорочення Термоусадки', key: 'ReducingShrinking', width: 30 },
            { header: 'Переріз', key: 'CrossSection', width: 30 }

        ];
        const os = require('os');
        var user = os.userInfo();
        worksheet.addRows(data)
        var routeForSaving = '\\\\leoni.local\\dfsroot\\UA1\\groups\\Austausch\\All_Deps\\instruction\\'
        var FileNames = 'instruction ' + Math.floor(Math.random() * 10000)
        await workbook.xlsx.writeFile(routeForSaving + FileNames + ".xlsx")
            .then(function () {

            });
        res.status(200).json('ok')
    }
    catch (e) {
        res.status(200).json(e.message)
    }


})


module.exports = router;
