const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let ussBaseSchema = new Schema({
    ['Загальний переріз']: {
        type: String,
        required:true
    },
    ['Опис комбінацій']:{
        type:String,
        required:true
    },
    ['Druck_-10%']:{
        type:String,
        required:true
    },
    ['Druck /  Тиск']:{
        type:String,
        required:true
    },
    ['Druck_10%']:{
        type:String,
        required:true
    },
    ['Breite / Ширина']:{
        type:String,
        required:true
    },
    ['Amplitude_-10%']:{
        type:String,
        required:true
    },
    ['Amplitude/Амплітуда']:{
        type:String,
        required:true
    },
    ['Amplitude_10%']:{
        type:String,
        required:true
    },
    ['Energie_-10%']:{
        type:String,
        required:true
    },
    ['Energie/Енергія']:{
        type:String,
        required:true
    },
    ['Energie_10%']:{
        type:String,
        required:true
    },
    ['Data/Дата затвердження']:{
        type:String,
        required:true
    },

    ['№ програми']:{
        type:String,
        required:true
    },
    
    equipment:{
        type:String,
        required:true
    },

    

}, {
    collection: 'ussBase'
})

module.exports = mongoose.model('ussBase', ussBaseSchema)