import * as React from 'react';
import validator from 'validator'
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import AssignmentIcon from '@material-ui/icons/Lock';
import FormControl from '@mui/material/FormControl';
import Link from '@mui/material/Link';
import FormHelperText from '@mui/material/FormHelperText'
import InputLabel from '@mui/material/InputLabel';
import {useState} from 'react';
import InputAdornment from '@mui/material/InputAdornment';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import Select from '@mui/material/Select';
import OutlinedInput from '@mui/material/OutlinedInput';
import {userType} from "../../../../../redux/reducers/authReducer";
import {helperText} from './selectors/helperTextEmail'
import MenuItem from '@mui/material/MenuItem';
type PropsType={
  isAuth:boolean
  isUniqueEmail:boolean
  message:string
  user:userType,
  checkEmail:(email:string)=>void
  setUser:(user: userType)=>void
}

type valuesType={
  firstName: string
  password:string
  department:string
  position:string
  lastName:string
  email:string
  passwordConfirmation:string
  getEmails:boolean
  showPassword:boolean
  showPasswordConfirmation:boolean
}

const SignUp:React.FC<PropsType>=(props)=>{

  const [values, setValues] = useState<valuesType>({
    firstName: '',
    password: '',
    department:'',
    position:'',
    lastName: '',
    email: '',
    passwordConfirmation:'',
    getEmails:false,
    showPassword: false,
    showPasswordConfirmation: false,
  });
  const[blurName,setBlurName]=useState<boolean>(false)
  const[blurEmail,setBlurEmail]=useState<boolean>(false)
  const[blurPassword,setBlurPassword]=useState<boolean>(false)
  const[blurConfirmationPassword,setBlurConfirmationPassword]=useState<boolean>(false)
  const[blurDepartment,setBlurDepartment]=useState<boolean>(false)
  const[blurPosition,setBlurPosition]=useState<boolean>(false)
  let setUserOnClick = ()=>{
    console.log(values.lastName)
   props.setUser(values)
}
const handleFocusName = () => {
  setBlurName(true);
};
const handleFocusDepartment = () => {
  setBlurDepartment(true);
};
const handleFocusPosition = () => {
  setBlurPosition(true);
};
const handleFocusEmail = () => {
 
  setBlurEmail(true);
};
const handleFocusConfirmationPassword = () => {
 
  setBlurConfirmationPassword(true);
};
const handleFocusPassword = () => {
  setBlurPassword(true);
};
  const handleChange = (prop:string) => (event:any) => {
    if(prop==='email')
     props.checkEmail(event.target.value)
      
     setValues({ ...values, [prop]: event.target.value });
    
  };

  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword,
    });
  };

  const handleClickShowPasswordConfirmation = () => {
    setValues({
      ...values,
      showPasswordConfirmation: !values.showPasswordConfirmation,
    });
  };

  const handleMouseDownPassword = (event:any) => {
    event.preventDefault();
  };
 
  return (
    <div>
     <Box
     
      component="form"
      sx={{
        '& .MuiTextField-root': { m: 1 }, marginLeft:'35%', 
      }}
      noValidate
      autoComplete="off"
    >
      <Avatar sx={{marginLeft:'24%',  bgcolor: '#f50057' }}>
        <AssignmentIcon />
      </Avatar>
      <Typography sx={{marginLeft:'20%'}}  variant='h4' color='textPrimary'  gutterBottom component="div" >
  Sign up
</Typography>

      <div>
      <FormControl sx={{ m: 1, width: '25%' }} variant="outlined">
      <InputLabel htmlFor="outlined-adornment-password" style={{color:blurName&&validator.isEmpty(values.firstName)?'#f44336':''}}>First Name</InputLabel>
          <OutlinedInput
            onBlur={handleFocusName}
            error={blurName&&validator.isEmpty(values.firstName)}
            //helperText={blurName&&validator.isEmpty(values.firstName)?'this field cannot be empty':''}
            id="outlined-adornment-firstName"
            type='text'
            value={values.firstName}
            onChange={handleChange('firstName')}
            required
            label="First Name"
          />
           <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{blurName&&validator.isEmpty(values.firstName)?'this field cannot be empty':''}</FormHelperText>
        </FormControl>
        <FormControl sx={{ m: 1, width: '25%' }} variant="outlined">
        <InputLabel htmlFor="outlined-adornment-password" style={{color:blurName&&validator.isEmpty(values.lastName)?'#f44336':''}}>Last Name</InputLabel>
          <OutlinedInput
            error={blurName&&validator.isEmpty(values.lastName)}
            id="outlined-adornment-password"
            type='text'
            value={values.lastName}
            onChange={handleChange('lastName')}
            required
            label="Last Name"
          />
           <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{blurName&&validator.isEmpty(values.lastName)?'this field cannot be empty':''}</FormHelperText>
        </FormControl>
        
      </div>
      <div>
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
      <InputLabel htmlFor="outlined-adornment-password" style={{color:blurDepartment&&validator.isEmpty(values.department)?'#f44336':''}}>Department</InputLabel>
      <Select
          onBlur={handleFocusDepartment}
          id="demo-simple-select-helper"
          value={values.department}
          label="Department"
          onChange={handleChange('department')}
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={'Production Engineering'}>Production Engineering</MenuItem>
          <MenuItem value={'Equipment Engineering'}>Equipment Engineering</MenuItem>
          <MenuItem value={'Cutting Engineering'}>Cutting Engineering</MenuItem>
          <MenuItem value={'Quality Engineering'}>Quality Engineering</MenuItem>
        </Select>
        <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{blurDepartment&&validator.isEmpty(values.department)?'this field cannot be empty':''}</FormHelperText>
        </FormControl>
      </div>
      <div>
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
      <InputLabel htmlFor="outlined-adornment-password" style={{color:blurPosition&&validator.isEmpty(values.position)?'#f44336':''}}>Position</InputLabel>
      <Select
           onBlur={handleFocusPosition}
          id="demo-simple-select-helper"
          value={values.position}
          label="Position"
          onChange={handleChange('position')}
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={'Manager'}>Manager</MenuItem>
          <MenuItem value={'Leader'}>Leader</MenuItem>
          <MenuItem value={'Engineer'}>Engineer</MenuItem>
         
        </Select>
        <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{blurPosition&&validator.isEmpty(values.position)?'this field cannot be empty':''}</FormHelperText>
        </FormControl>
      </div>
      <div>
       
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
      <InputLabel htmlFor="outlined-adornment-password" style={{color:blurEmail && (!(validator.isEmail(values.email))||(!props.isUniqueEmail))?'#f44336':''}}>Email Address</InputLabel>
          <OutlinedInput
          onBlur={handleFocusEmail}
          error={blurEmail && (!(validator.isEmail(values.email))||(!props.isUniqueEmail))}
          //helperText={helperText(values.email, blurEmail, props.isUniqueEmail )}
           
            id="outlined-adornment-email"
            type='text'
            value={values.email}
            onChange={handleChange('email')}
            required
            label="Email Address"
          />
            <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{helperText(values.email, blurEmail, props.isUniqueEmail )}</FormHelperText>
        </FormControl>
      
      </div>
      <div>
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
      <InputLabel htmlFor="outlined-adornment-password" style={{color:blurPassword&&(!validator.isStrongPassword(values.password))?'#f44336':''}}>Password</InputLabel>
          <OutlinedInput
          onBlur={handleFocusPassword}
          error={blurPassword&&!(validator.isStrongPassword(values.password))}
           //helperText={blurPassword&&(!validator.isStrongPassword(values.password))?'your password not enough strong':''}
            id="outlined-adornment-password"
         
            type={values.showPassword ? 'text' : 'password'}
            value={values.password}
            required
            onChange={handleChange('password')}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {values.showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />
          <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{blurPassword&&(!validator.isStrongPassword(values.password))?'your password not enough strong':''}</FormHelperText>
        </FormControl>

      </div>
      <div>
      <FormControl sx={{ m: 1, width: '52%' }} variant="outlined">
      <InputLabel htmlFor="outlined-adornment-password" style={{color:blurConfirmationPassword&&(values.password!==values.passwordConfirmation)?'#f44336':''}}>Password Confirmation</InputLabel>
          <OutlinedInput
          onBlur={handleFocusConfirmationPassword}
          error={blurConfirmationPassword&&(values.password!==values.passwordConfirmation)}
           //helperText={blurPassword&&(!validator.isStrongPassword(values.password))?'your password not enough strong':''}
            id="outlined-adornment-password"
          
            type={values.showPasswordConfirmation ? 'text' : 'password'}
            value={values.passwordConfirmation}
            required
            onChange={handleChange('passwordConfirmation')}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPasswordConfirmation}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {values.showPasswordConfirmation ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Password confirmation"
          />
          <FormHelperText style={{color:'#f44336', marginLeft:'2%'}}>{values.password!==values.passwordConfirmation?'your confirmation password not the same with password':''}</FormHelperText>
        </FormControl>

      </div>
      <FormGroup>
      <FormControlLabel  sx={{color:'#d7dac4', width: '52%',  marginLeft:'1%'}} control={<Checkbox 
       onChange={handleChange('getEmails')}
      
      />} label='I want get all updates in bases with email'/>
  
    </FormGroup>
    <Button sx={{ m: 1, width: '52%' }} onClick={setUserOnClick}  variant="contained">SIGN UP</Button>
    <div style={{ width: '52%',  marginLeft:'28%', textDecoration:'none'}}>
    <Link  href='#' sx={{ marginLeft:'31%', width:'52%', textDecoration:'none'}} color='primary' >Already have an account?Sign in</Link>
    </div>
    </Box>
    </div>
  );
}


export default React.memo(SignUp)