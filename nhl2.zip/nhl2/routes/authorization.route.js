let mongoose = require('mongoose'),
    express = require('express'),
    router = express.Router();

let bodyParser= require('body-parser')
let jwt  = require('jsonwebtoken')
let userSchema = require('./models/User')

var jsonParser = bodyParser.json()
let bcrypt  = require('bcryptjs')

var urlencodedParser = bodyParser.urlencoded({ extended: false });


// Sign UP
router.route('/create-user').post(urlencodedParser, async(req, res, next) => {
    try{
   
    let{firstName, lastName, password, email, position, department, getEmails}=req.body.userObject
           const salt=await bcrypt.genSalt()
            const passwordHash=await bcrypt.hash(password, salt)
            const newUser=new userSchema({firstName, lastName, position, department, password:passwordHash,
            email, getEmails})
           const savedUser =  await  newUser.save()
           const token=jwt.sign({email:newUser.email, name:firstName + ' ' + lastName,  id:newUser._id}, 'test', {expiresIn:'1h'})
            let answer={
                user:savedUser,
                message:"user created successfully",
                isAuth:true,
                token
            }
            res.status(200).json(answer) 
        }
   
        catch(e){
            console.log('wror is ' + e.stack)
           res.status(404).json('wrong data')
          }
    
});
//Sign IN
router.route('/signIn').post(urlencodedParser, async(req, res, next) => {
    let{password, email}=req.body.userObject
    try{
          const existingUser=await userSchema.findOne({email})  
          if(!existingUser) return res.status(404).json({message:"user doesn't exist"})
          const isPasswordCorrect=await bcrypt.compare(password, existingUser.password);
          if(!isPasswordCorrect) return res.status(400).json({message:"invalid credentials"})
             const token = jwt.sign({email:existingUser.email, name:existingUser.firstName + ' ' + existingUser.lastName}, 'test', {expiresIn:"1h"})
             let answer={
                user:existingUser,
                message:"user created successfully",
                isAuth:true,
                token
            }
             res.status(200).json(answer)
            }
   
        catch(e){
            console.log('wror is ' + e.stack)
           res.status(500).json('something went wrong')
          }
    
});


//Check Email
router.route('/checkEmail').post((req, res, next) => {

    userSchema.findOne({email:req.body.email}).then((user)=>{

        if (user){
           
           res.status(200).json({uniqueEmail:false})
        }

        else {
           res.status(200).json({uniqueEmail:true})
        }
    })

});
//Check Email
router.route('/getUsers').get(urlencodedParser, (req, res) => {





    userSchema.find({}, (error, data) => {
        console.log('length of data inside is '  + data.length)
        if (error) {
            console.log('it was error')
            return next (error)
        } else {
            res.json(data)
        }
    })
})



module.exports = router;
