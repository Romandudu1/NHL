import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Checkbox from '@mui/material/Checkbox';
import Avatar from '@mui/material/Avatar';

const  TeamSelected:React.FC<any>=(props:any)=>{
  const [checked, setChecked] = React.useState([1]);

  const handleToggle = (value:any) => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }

    setChecked(newChecked);
  };

  return (
    <List  sx={{ width:'30vw', bgcolor: 'background.paper' }}>
      {props.roster.map((value:any) => {
        const labelId = `checkbox-list-secondary-label-${value}`;
        return (
          <ListItem
            key={value.person?value.person.fullName:'not selected team'}
            secondaryAction={
              <Checkbox
                edge="end"
                onChange={handleToggle(value)}
                checked={checked.indexOf(value) !== -1}
                inputProps={{ 'aria-labelledby': labelId }}
              />
            }
            disablePadding
          >
            <ListItemButton>
              <ListItemAvatar>
                <Avatar
             
                  alt={value.position?value.position.abbreviation:'not selected team'}
                  src={`/static/images/avatar/${value + 1}.jpg`}
                />
              </ListItemAvatar>
              <ListItemText id={labelId} style={{width:'5vw'}} primary={value.person?<span style={{fontSize:'1.2vw'}}>{value.person.fullName}</span>:'not selected'} />
              <ListItemText   id={labelId} primary={value.person?<span style={{fontSize:'1.2vw'}}>{(value.person.level).toFixed(3)}</span>:'not selected'} />
            </ListItemButton>
          </ListItem>
        );
      })}
    </List>
  );
}
export default React.memo(TeamSelected);