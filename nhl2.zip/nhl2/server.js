let express = require('express');
let mongoose = require('mongoose');
let cors = require('cors');
require('dotenv').config()
let bodyParser = require('body-parser');
let dbConfig = require('./database/db');
let fileUpload=require('express-fileupload');
var jsonParser = bodyParser.json()
const WebSocket = require('ws');
const authRoute=require('./routes/authorization.route')
const productionRoute=require('./routes/production.route')
const equipmentRoute=require('./routes/equipmentengineering.route')

const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', function connection(ws) {
    console.log('connections is working!')
  ws.on('message', function incoming(data) {
      console.log('message is send ' + data)
    wss.clients.forEach(function each(client) {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(data);
        // console.log('data', data);
      }
    });
  });
});
// Connecting mongoDB Database
mongoose.Promise = global.Promise;
/*const serverOptions = {

    connectTimeoutMS: 5000,
        socketTimeoutMS: 5000,
    useUnifiedTopology: true

    };*/
mongoose.connect(dbConfig.db, {
    connectTimeoutMS: 5000,
    socketTimeoutMS: 5000,
    useUnifiedTopology: true
}).then(() => {
        console.log('Database sucessfully connected!')
    },
    error => {
        console.log('Could not connect to database : ' + error)
    }
)

const app = express();
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(cors());
app.use(fileUpload({
    createParentPath: true
}))
var urlencodedParser = bodyParser.urlencoded({ extended: false });
/*app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));*/


app.use('/auth', authRoute)
app.use('/production', productionRoute)
app.use('/equipment', equipmentRoute)
// PORT
const port = process.env.PORT || 4000;
const server = app.listen(port, () => {
    console.log('Connected to port ' + port)
})
server.setTimeout(10*60*1000);
// 404 Error
app.use((req, res, next) => {
    // eslint-disable-next-line no-undef
    next(createError(404));
});

app.use(function (err, req, res, next) {
    console.error(err.message);
    if (!err.statusCode) err.statusCode = 500;
    res.status(err.statusCode).send(err.message);
});
